/*
using System;
using System.Collections.Generic;
using System.Linq;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Crewmate;

public sealed class VillageHead : RoleBase, IKiller
{
    private static OptionItem OptionKillCooldown;

    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(VillageHead),
            player => new VillageHead(player),
            CustomRoles.VillageHead,
            () => RoleTypes.Impostor, // 🌟 シェリフと完全に同じインポスター偽装
            CustomRoleTypes.Crewmate, // クルー陣営
            9273,
            SetUpOptionItem,
            "VillageHead",
            "#f8cd46",
            true, // 🌟 シェリフと同じ設定に統一
            introSound: () => GetIntroSound(RoleTypes.Crewmate)
        );

    public VillageHead(PlayerControl player)
        : base(RoleInfo, player, () => HasTask.False)
    {
        // 初期クールダウン設定などが必要な場合はここで初期化
    }

    enum OptionName
    {
        VillageHeadKillCooldown,
    }

    private static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.VillageHeadKillCooldown, new(10f, 60f, 2.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);
    }

    // 🌟 シェリフの判定ロジックを踏襲。自分が「村長」である限りキルボタンを絶対に表示する
    public bool CanUseKillButton() => Player.IsAlive() && Player.GetCustomRole() == CustomRoles.VillageHead;
    public bool CanUseSabotageButton() => false;
    public bool CanUseImpostorVentButton() => false;

    bool IKiller.IsKiller => false; // クルーカウント

    public float CalculateKillCooldown() => CanUseKillButton() ? OptionKillCooldown.GetFloat() : 0f;

    // 🌟 シェリフ同様、キルボタンが押された瞬間のフック
    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        if (Is(info.AttemptKiller) && !info.IsSuicide)
        {
            (var killer, var target) = info.AttemptTuple;

            // ボタンが押されたら、バニラの即死キルは絶対にキャンセルする
            info.DoKill = false;

            if (target == null || target.Data.IsDead) return;

            // ボタン連打などによる二重発動を防ぐガード
            if (Player.GetCustomRole() != CustomRoles.VillageHead) return;

            if (AmongUsClient.Instance.AmHost)
            {
                ExecuteVillageHeadAbility(target);
            }
        }
    }

    private void ExecuteVillageHeadAbility(PlayerControl target)
    {
        if (!target.GetCustomRole().IsImpostor() && !target.GetCustomRole().IsNeutral())
        {
            Logger.Info($"[VillageHead] {Player.name} が {target.name} に能力を譲渡します。", "VillageHead");

            // 1. タスク完了処理
            foreach (var task in target.Data.Tasks.ToArray())
            {
                target.RpcCompleteTask(task.Id);
            }

            // 2. TOH内部のカスタム役職書き換え
            target.RpcSetCustomRole(CustomRoles.Sheriff);
            Player.RpcSetCustomRole(CustomRoles.Crewmate);

            // 3. BANされない特定個人向けRPC（RpcSetRoleDesync）でバニラ役職の視点をすり替え
            if (AmongUsClient.Instance.AmHost)
            {
                // 新シェリフに Impostor 視点（キルボタン権限）を安全に付与
                WriteRoleType.OverrideSetRolePatch(target, RoleTypes.Impostor);
                target.RpcSetRoleDesync(RoleTypes.Crewmate, target.GetClientId());

                // 旧村長（自分）から Crewmate 視点に戻してキルボタンを消去
                WriteRoleType.OverrideSetRolePatch(Player, RoleTypes.Crewmate);
                Player.RpcSetRoleDesync(RoleTypes.Crewmate, Player.GetClientId());
            }

            // 4. クールダウン・画面同期
            target.ResetKillCooldown();
            target.SetKillCooldown();
            target.RpcResetAbilityCooldown();

            Utils.NotifyRoles();
        }
        else
        {
            // 失敗ルート：BANされない MurderPlayerRPC 経由でのペナルティ自殺
            var myState = TownOfHost.PlayerState.GetByPlayerId(Player.PlayerId);
            if (myState != null) myState.DeathReason = CustomDeathReason.Suicide;
            Player.RpcMurderPlayer(Player);
        }
    }
}
*/