using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Neutral;

public class JekyllAndHyde : RoleBase, IKiller
{
    // --- 役職の静的情報・登録設定 ---
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(JekyllAndHyde),
            player => new JekyllAndHyde(player),
            CustomRoles.JekyllAndHyde,
            () => RoleTypes.Impostor,        // インポスター判定（シェリフ黒判定など）
            CustomRoleTypes.Crewmate,        // クルーカウント
            86050,                           // ロールID
            null,
            "jah",                           // CSVキー（言語リソースと一致させる）
            "#FF0000",                       // 役職カラー
            isDesyncImpostor: true,          // Desync処理
            introSound: () => GetIntroSound(RoleTypes.Crewmate)
        );

    // --- ターン管理（全インスタンス共有） ---
    public static int CurrentTurn = 1;

    // 判定プロパティ（奇数：ジキル / 偶数：ハイド）
    public static bool IsJekyll => CurrentTurn % 2 != 0;
    public static bool IsHyde => CurrentTurn % 2 == 0;

    // --- コンストラクタ ---
    public JekyllAndHyde(PlayerControl player) : base(RoleInfo, player, () => HasTask.False)
    {
    }

    // --- ゲーム開始/リセット時 ---
    public static void ResetTurn()
    {
        CurrentTurn = 1;
    }

    // --- 会議明け（タスクフェイズ開始時）に呼び出す処理 ---
    public static void OnTaskPhaseStart()
    {
        CurrentTurn++;

        // 偶数ターン（ハイド）になった場合、全ジキル＆ハイドのキルタイマーをリセット
        if (IsHyde)
        {
            foreach (var player in PlayerControl.AllPlayerControls)
            {
                if (player == null || !player.IsAlive()) continue;

                if (player.GetRoleClass() is JekyllAndHyde jekyll)
                {
                    jekyll.ResetKillCooldown();
                }
            }
        }
    }

    // キルクールダウンのリセット処理
    public void ResetKillCooldown()
    {
        if (Player == null) return;
        Player.SetKillTimer(CalculateKillCooldown());
    }

    // --- アビリティ・ボタン制御 ---

    // キルボタン制御（ハイド時のみ有効）
    public bool CanUseKillButton()
    {
        if (Player == null || !Player.IsAlive()) return false;
        return IsHyde;
    }

    // ベントボタン制御（ハイド時、または既にベント内にいる時のみ有効）
    public bool CanUseVentButton()
    {
        if (Player == null || !Player.IsAlive()) return false;
        return IsHyde || Player.inVent;
    }

    public bool CanUseImpostorVentButton()
    {
        if (Player == null || !Player.IsAlive()) return false;
        return IsHyde || Player.inVent;
    }

    // サボタージュボタン制御（常に不可）
    public bool CanUseSabotageButton() => false;
    public bool CanUseImpostorSabotageButton() => false;

    // キルクールダウン計算
    public float CalculateKillCooldown()
    {
        return GameOptionsManager.Instance.CurrentGameOptions.GetFloat(FloatOptionNames.KillCooldown);
    }

    // IKiller の実装：ハイド時のみキラー扱い
    bool IKiller.IsKiller => IsHyde;

    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        if (Is(info.AttemptKiller))
        {
            // ジキル（奇数ターン）時はキルを強制キャンセル
            if (IsJekyll)
            {
                info.DoKill = false;
            }
        }
    }
}