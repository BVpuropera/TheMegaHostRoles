using System.Collections.Generic;
using AmongUs.GameOptions;
using HarmonyLib;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Impostor;

public sealed class Rocket : RoleBase, IImpostor
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Rocket),
            player => new Rocket(player),
            CustomRoles.Rocket,
            () => RoleTypes.Shapeshifter, // 💡 ベースをシェイプシフターに変更！
            CustomRoleTypes.Impostor,
            564,
            null,
            "Rocket",
            "#FF0000",
            false
        );

    public Rocket(PlayerControl player) : base(RoleInfo, player) { }

    // 🚀 ホスト側で誰を掴んでいるかを保持する静的変数 (255は誰も掴んでいない状態)
    public static byte GrabbedPlayerId = 255;
    public bool CanBeLastImpostor { get; } = true;

    // 💡 通常キルボタンは一切使わせない（バニラの通常キルは常に無効化）
    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        info.DoKill = false;
    }

    // 💡 掴んでいる最中の毎フレーム座標同期（テレポート）
    public override void OnFixedUpdate(PlayerControl _)
    {
        if (!AmongUsClient.Instance.AmHost || !GameStates.IsInTask) return;
        if (GrabbedPlayerId == 255) return;

        var target = Utils.GetPlayerById(GrabbedPlayerId);
        if (target != null && target.IsAlive())
        {
            // 掴んでいる相手をロケットの位置へ強制吸着
            target.NetTransform.RpcSnapTo(Player.transform.position);
        }
        else
        {
            GrabbedPlayerId = 255;
        }
    }

    // 【変身ボタン押下時の処理】を完全にオーバーライドしてロケットの挙動にする
    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        // 自身が死亡している、またはベント内なら不発
        if (Player.Data.IsDead || Player.inVent) return false;

        // 💡 演出用のバニラ変身アニメーションは強制的にオフ
        animate = false;

        if (target != null)
        {
            // 💡 判定と処理の確定は、すべてホスト側のタイムラインに一元化する
            if (AmongUsClient.Instance.AmHost)
            {
                // ➔ 【打ち上げ判定】すでに掴んでいるプレイヤーをもう一度選んだとき（キル実行）
                if (GrabbedPlayerId == target.PlayerId)
                {
                    var state = PlayerState.GetByPlayerId(target.PlayerId);
                    if (state != null && !state.IsDead)
                    {
                        state.DeathReason = CustomDeathReason.Bite; // 死亡理由をセット

                        // 元の陣営に合わせて、直接セットするゴースト役職を決定
                        RoleTypes ghostRole = target.Data.Role.IsImpostor
                            ? RoleTypes.ImpostorGhost
                            : RoleTypes.CrewmateGhost;

                        target.RpcSetRole(ghostRole); // 直接ゴースト化（死体が出ない）
                        state.SetDead();              // TOH側の死亡フラグを確定

                        RPC.PlaySoundRPC(Player.PlayerId, Sounds.KillSound);
                        Debug.Log($"[Rocket] {target.name} を宇宙へ打ち上げました！");
                    }

                    // ホスト側で掴み状態を解除
                    GrabbedPlayerId = 255;

                    // 💡 発射後は即座に復活させず、通常のクールダウン（設定した5秒など）に入らせる
                }
                // ➔ 【新規掴み判定】まだ誰も掴んでいない、または別のプレイヤーを指定したとき
                else
                {
                    // 既に誰か掴んでいたら一旦リセット
                    if (GrabbedPlayerId != 255)
                    {
                        GrabbedPlayerId = 255;
                    }

                    // 新しいターゲットをホールド
                    GrabbedPlayerId = target.PlayerId;
                    Debug.Log($"[Rocket] {target.name} をロックオン（ホールド）しました。");

                    // 🚀 掴み成功時は、次の「発射（2回目）」をすぐ打てるように即座にボタンを復活させる！
                    Player.RpcResetAbilityCooldown();
                }
            }
        }

        // 🛑 本物のシェイプシフターに変身するのを完全に阻止する
        return false;
    }
}