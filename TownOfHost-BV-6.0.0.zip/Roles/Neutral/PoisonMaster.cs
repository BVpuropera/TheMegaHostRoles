using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using AmongUs.GameOptions;

using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using static TownOfHost.Translator;
using Hazel;

namespace TownOfHost.Roles.Neutral;

public sealed class PoisonMaster : RoleBase
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(PoisonMaster),
            player => new PoisonMaster(player),
            CustomRoles.PoisonMaster,
            () => RoleTypes.Impostor, // インポスターベースに変更
            CustomRoleTypes.Neutral,
            50205,
            SetupOptionItem,
            "po",
            "#00ff00"
        );

    public PoisonMaster(PlayerControl player) : base(RoleInfo, player)
    {
        PoisonMasters.Add(this);
        if (PoisonMasters.Count == 1)
        {
            PoisonedPlayerId = 255;
            CustomRoleManager.OnMurderPlayerOthers.Add(OnMurderPlayerOthers);
        }
    }

    public override void OnDestroy()
    {
        PoisonMasters.Clear();
        PoisonedPlayerId = 255;
    }

    private static void SetupOptionItem() { }

    public static List<PoisonMaster> PoisonMasters = new();
    public static byte PoisonedPlayerId { get; set; } = 255;

    public override void Add()
    {
        PoisonedPlayerId = 255;
    }

    public static void OnMurderPlayerOthers(MurderInfo info)
    {
        var (killer, target) = info.AttemptTuple;

        // ポイズンマスター自身が死んだら罠解除
        if (PoisonMasters.Count > 0 && target.PlayerId == PoisonMasters[0].Player.PlayerId)
        {
            PoisonedPlayerId = 255;
            Logger.Info("ポイズンマスターが死亡したため、毒トラップが解除されました。", "PoisonMaster");
        }
    }

    // 💡 ここで死体通報をフックして乗っ取る！
    public override void OnReportDeadBody(PlayerControl reporter, NetworkedPlayerInfo targetReported)
    {
        if (!AmongUsClient.Instance.AmHost) return;

        // 毒が有効、かつ通報された死体が「毒を盛られたプレイヤー」の場合
        if (PoisonedPlayerId != 255 && targetReported.PlayerId == PoisonedPlayerId)
        {
            Logger.Info($"毒殺対象 {targetReported.PlayerName} の死体が通報されたため、ポイズンマスターが勝利を乗っ取ります。", "PoisonMaster");
            Win();
        }
    }

    // 海賊王方式の全員爆散単独勝利ロジック
    private void Win()
    {
        foreach (var pc in Main.AllAlivePlayerControls)
        {
            // 自分以外の全プレイヤーをキルする
            if (pc.PlayerId != Player.PlayerId)
            {
                pc.SetRealKiller(Player);
                pc.RpcMurderPlayer(pc);
                var state = PlayerState.GetByPlayerId(pc.PlayerId);
                state.DeathReason = CustomDeathReason.Infected; // 死亡理由を毒に（無ければ適宜変更）
                state.SetDead();
            }
        }

        // 勝者をポイズンマスターに書き換えて終了
        CustomWinnerHolder.ShiftWinnerAndSetWinner(CustomWinner.PoisonMaster);
        CustomWinnerHolder.WinnerIds.Add(Player.PlayerId);
    }

    // --- RPC同期用メソッド ---
    public void SendRPC(byte targetId)
    {
        using var sender = CreateSender();
        sender.Writer.Write(targetId);
    }

    public override void ReceiveRPC(MessageReader reader)
    {
        var targetId = reader.ReadByte();
        PoisonedPlayerId = targetId;
        Logger.Info($"[RPC] ポイズンした対象のIDを受信: {targetId}", "PoisonMaster");
    }
}