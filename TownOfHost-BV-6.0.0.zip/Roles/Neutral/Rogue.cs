using System;
using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;
using HarmonyLib; // 🌟 Harmonyパッチを使うために必要です

namespace TownOfHost.Roles.Neutral;

public sealed class Rogue : RoleBase, IKiller
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Rogue),
            player => new Rogue(player),
            CustomRoles.Rogue,
            () => RoleTypes.Shapeshifter,
            CustomRoleTypes.Neutral,
            0283,
            SetUpOptionItem,
            "Rogue",
            "#B998C5",
            isDesyncImpostor: true,
            countType: CountTypes.Rogue, // 環境に合わせてこのままでOK！
            assignInfo: new RoleAssignInfo(CustomRoles.Rogue, CustomRoleTypes.Neutral)
            {
                AssignCountRule = new(1, 1, 1)
            }
        );

    public static List<Rogue> Rogues = new();

    public CustomRoles StolenRole { get; private set; } = CustomRoles.Rogue;
    private RoleBase _stolenRoleInstance = null;

    bool IKiller.IsKiller => true;

    static OptionItem OptionKillCooldown;
    static OptionItem OptionShiftCooldown;

    public Rogue(PlayerControl player) : base(RoleInfo, player)
    {
        StolenRole = CustomRoles.Rogue;
        Rogues.Add(this);

        _ = new LateTask(() =>
        {
            if (Player == null || !Player.IsAlive()) return;
            if (AmongUsClient.Instance.AmHost)
            {
                Player.ResetKillCooldown();
                Utils.SyncAllSettings();
            }
        }, 0.5f, "RogueButtonInit");

        if (AmongUsClient.Instance.AmHost)
        {
            CustomRoleManager.MarkOthers.Add(GetMarkOthers);
        }
    }

    public override void OnDestroy()
    {
        Rogues.Remove(this);
    }

    enum OptionName
    {
        RogueKillCooldown,
        RogueShiftCooldown,
    }

    static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.RogueKillCooldown, new(10f, 60f, 2.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);
        OptionShiftCooldown = FloatOptionItem.Create(RoleInfo, 11, OptionName.RogueShiftCooldown, new(10f, 60f, 2.5f), 20f, false)
            .SetValueFormat(OptionFormat.Seconds);
    }

    public bool CanUseKillButton() => Player.IsAlive();
    public bool CanUseSabotageButton() => false;
    public bool CanUseImpostorVentButton() => false;

    public float CalculateKillCooldown() => OptionKillCooldown.GetFloat();

    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        if (Is(info.AttemptKiller) && !info.IsSuicide)
        {
            (_, var target) = info.AttemptTuple;
            if (target == null) return;

            var targetRole = target.GetCustomRole();
            StealRoleAbility(targetRole);
        }
    }

    private void StealRoleAbility(CustomRoles newRole)
    {
        StolenRole = newRole;
        Logger.Info($"[Rogue] {Player.Data.PlayerName} が役職 {newRole} の能力を奪いました。", "Rogue");

        try
        {
            var targetRoleInfo = newRole.GetRoleInfo();
            if (targetRoleInfo != null)
            {
                _stolenRoleInstance = targetRoleInfo.CreateInstance(Player);
                _stolenRoleInstance?.Add();
                Logger.Info($"[Rogue] {newRole} のインスタンスを内部生成しました。", "Rogue");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[Rogue] インスタンス生成に失敗: {ex.Message}", "Rogue");
        }

        Utils.NotifyRoles();
    }

    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        if (Player.Data.IsDead || Player.inVent) return false;

        if (StolenRole == CustomRoles.Rogue || _stolenRoleInstance == null)
        {
            if (Player.AmOwner)
            {
                Logger.SendInGame("まだ能力を奪っていません！キルして能力を強奪してください。");
            }
            return false;
        }

        Logger.Info($"[Rogue] 奪った役職 ({StolenRole}) の能力をシェイプシフトボタン経由で発動します。", "Rogue");
        ExecuteStolenRoleAbility(target, ref animate);
        return false;
    }

    private void ExecuteStolenRoleAbility(PlayerControl target, ref bool animate)
    {
        if (!AmongUsClient.Instance.AmHost) return;
        _stolenRoleInstance?.OnCheckShapeshift(target, ref animate);
    }

    public static string GetMarkOthers(PlayerControl seer, PlayerControl seen = null, bool isForMeeting = false)
    {
        seen ??= seer;
        if (seen.Is(CustomRoles.Rogue))
        {
            Rogue rogueInstance = Rogues.Find(r => r.Player.PlayerId == seen.PlayerId);

            if (rogueInstance != null && rogueInstance.StolenRole != CustomRoles.Rogue)
            {
                if (seer.PlayerId == seen.PlayerId || AmongUsClient.Instance.AmHost)
                {
                    return $" [<color=#B998C5>{rogueInstance.StolenRole}</color>]";
                }
            }
        }
        return "";
    }

    // 🌟 【ローグ単独勝利をシステムに叩き込むHarmonyパッチ】
    [HarmonyPatch(typeof(AmongUsClient), nameof(AmongUsClient.OnGameEnd))]
    class RogueWinOverridePatch
    {
        public static void Prefix()
        {
            Rogue aliveRogue = null;
            foreach (var rogue in Rogues)
            {
                if (rogue.Player != null && rogue.Player.IsAlive())
                {
                    aliveRogue = rogue;
                    break;
                }
            }

            if (aliveRogue != null)
            {
                CustomWinnerHolder.ShiftWinnerAndSetWinner((CustomWinner)CustomRoles.Rogue);
                CustomWinnerHolder.WinnerIds.Clear();
                CustomWinnerHolder.WinnerIds.Add(aliveRogue.Player.PlayerId);

                Logger.Info($"[Rogue] ローグ生存による単独勝利を確定させました。PlayerId: {aliveRogue.Player.PlayerId}", "Rogue");
            }
        }
    }
}