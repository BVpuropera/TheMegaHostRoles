using System.Collections.Generic;
using UnityEngine;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using static TownOfHost.Translator;
using Hazel;

namespace TownOfHost.Roles.Neutral
{
    public sealed class God : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(God),
                player => new God(player),
                CustomRoles.God,
                () => RoleTypes.Crewmate,
                CustomRoleTypes.Neutral,
                019928,
                SetupOptionItem,
                "god",
                "#FFD700",
                true
            );

        private static Options.OverrideTasksData Tasks;

        public God(PlayerControl player) : base(RoleInfo, player, () => HasTask.ForRecompute)
        {
        }

        private static void SetupOptionItem()
        {
            Tasks = Options.OverrideTasksData.Create(RoleInfo, 20);
        }

        public override void OnFixedUpdate(PlayerControl player)
        {
            if (!AmongUsClient.Instance.AmHost) return;

            if (!Player.Data.IsDead && Player.AllTasksCompleted() && GameStates.IsInTask)
            {
                // 必要に応じてタスク完了時の処理を記述
            }
        }

        // 追放会議終了（WrapUp）時に勝利判定
        public override void OnExileWrapUp(NetworkedPlayerInfo exiled, ref bool DecidedWinner)
        {
            if (DecidedWinner) return;

            // 「神」自身が生存しており、タスクを全て完了しているか判定
            if (!Player.Data.IsDead && Player.AllTasksCompleted())
            {
                Win();
                DecidedWinner = true; // TOHの勝利判定を乗っ取る
            }
        }

        private void Win()
        {
            CustomWinnerHolder.ShiftWinnerAndSetWinner(CustomWinner.God);
            CustomWinnerHolder.WinnerIds.Add(Player.PlayerId);
        }

        public override string GetLowerText(PlayerControl seer, PlayerControl seen = null, bool isForMeeting = false, bool isForHud = false)
        {
            // 自分が「神」の場合の下部テキスト表示
            if (Is(seer) && !isForMeeting && isForHud)
            {
                return Player.AllTasksCompleted()
                    ? Utils.ColorString(RoleInfo.RoleColor, "タスク完了！最後まで生き残れ！")
                    : Utils.ColorString(new Color32(200, 200, 200, 255), "タスクを全完了させて生存を目指せ");
            }

            return "";
        }

        // 神視点：他プレイヤーのネームプレート用
        public static string GetTargetRoleNameForGod(PlayerControl godPlayer, PlayerControl targetPlayer)
        {
            if (godPlayer == null || targetPlayer == null) return "";

            // TOH標準のユーティリティを使用して役職名とネームカラーを取得
            var targetRole = targetPlayer.GetCustomRole();
            var roleColor = Utils.GetRoleColor(targetRole);
            var roleName = Utils.GetRoleName(targetRole);

            return Utils.ColorString(roleColor, $"({roleName})");
        }
    }
}