using System;
using System.Collections;
using System.Collections.Generic;
using AmongUs.GameOptions;
using BepInEx.Unity.IL2CPP.Utils;
using HarmonyLib;
using Hazel;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Vanilla;
using UnityEngine;

namespace TownOfHost.Roles.Neutral
{
    public class Overbird : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(Overbird),
                player => new Overbird(player),
                CustomRoles.Overbird,
                () => RoleTypes.Shapeshifter, // 判定：シェイプシフター
                CustomRoleTypes.Neutral,       // 陣営：第三陣営
                888,                           // Role ID
                SetupOptionItem,
                "overbird",                    // キー名
                "#800080",                     // ネームカラー（紫色）
                true                           // カウント：クルーメイト
            );

        public static HashSet<byte> MarkedPlayers = new();

        public Overbird(PlayerControl player) : base(RoleInfo, player, null, null)
        {
            MarkedPlayers.Clear();
        }

        private static void SetupOptionItem()
        {
        }

        public override void Add()
        {
            MarkedPlayers.Clear(); // ゲーム開始時にターゲットリストをリセット

            if (AmongUsClient.Instance.AmHost)
            {
                _ = new LateTask(() =>
                {
                    if (Player != null)
                    {
                        // 自分自身に対して Shapeshifter として視点をDesync設定
                        Player.RpcSetRoleDesync(RoleTypes.Shapeshifter, Player.GetClientId());
                    }
                }, 0.5f, "Overbird Desync Set");
            }
        }

        // 【変身ボタン押下時の処理】
        public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
        {
            if (Player.Data.IsDead || Player.inVent) return false;

            if (Player.GetCustomRole() != CustomRoles.Overbird)
            {
                return true;
            }

            animate = false;

            if (target != null && target != Player)
            {
                if (AmongUsClient.Instance.AmHost)
                {
                    // 対象をメモ（×印）に追加
                    if (!MarkedPlayers.Contains(target.PlayerId))
                    {
                        MarkedPlayers.Add(target.PlayerId);
                    }
                }
            }

            return false;
        }

        // 会議終了（WrapUp）時にメモした対象がいて自身が生き残っていれば勝利処理実行
        public override void OnExileWrapUp(NetworkedPlayerInfo exiled, ref bool DecidedWinner)
        {
            if (!AmongUsClient.Instance.AmHost) return;

            // 生存しており、1人以上メモしている場合に勝利
            if (!DecidedWinner && !Player.Data.IsDead && MarkedPlayers.Count > 0)
            {
                Win();
                DecidedWinner = true;
            }
        }

        private void Win()
        {
            foreach (var pc in Main.AllAlivePlayerControls)
            {
                if (pc.PlayerId != Player.PlayerId)
                {
                    pc.SetRealKiller(Player);
                    pc.RpcMurderPlayer(pc);
                    var state = PlayerState.GetByPlayerId(pc.PlayerId);
                    if (state != null)
                    {
                        state.DeathReason = CustomDeathReason.Kill;
                        state.SetDead();
                    }
                }
                else
                {
                    RPC.PlaySoundRPC(pc.PlayerId, Sounds.KillSound);
                }
            }
            CustomWinnerHolder.ShiftWinnerAndSetWinner(CustomWinner.PirateKing);
            CustomWinnerHolder.WinnerIds.Add(Player.PlayerId);
        }

        // ターゲット視点：名前の横に × を表示
        public static string GetTargetNamePrefix(PlayerControl seer, PlayerControl target)
        {
            if (seer != null && target != null && MarkedPlayers.Contains(target.PlayerId))
            {
                return Utils.ColorString(Color.red, "× ");
            }
            return "";
        }
    }
}