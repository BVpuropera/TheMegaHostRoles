/*
using System.Collections.Generic;
using AmongUs.GameOptions;
using HarmonyLib;

namespace TownOfHost
{
    public static class WriteRoleType
    {
        private static readonly Dictionary<byte, RoleTypes> PendingRoleChanges = new();

        /// <summary>
        /// 指定したプレイヤーの役職を変更します。<br/>
        /// </summary>
        /// <param name="target">The player whose role to set.</param>
        /// <param name="targetRole">The role to assign.</param>
        public static void OverrideSetRolePatch(PlayerControl target, RoleTypes targetRole)
        {
            if (target == null) return;
            PendingRoleChanges[target.PlayerId] = targetRole;
        }

        // 送ってもBANされない「個別視点RPC（RpcSetRoleDesync）」をフック
        [HarmonyPatch(typeof(PlayerControl), "RpcSetRoleDesync")]
        private static class RpcSetRoleDesyncPatch
        {
            public static void Prefix(PlayerControl __instance, ref RoleTypes role)
            {
                if (__instance == null) return;

                if (PendingRoleChanges.TryGetValue(__instance.PlayerId, out RoleTypes targetRole))
                {
                    role = targetRole;
                    PendingRoleChanges.Remove(__instance.PlayerId);
                }
            }
        }
    }
}
*/