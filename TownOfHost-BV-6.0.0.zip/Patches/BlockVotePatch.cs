using HarmonyLib;
using TownOfHost.Modules;
using UnityEngine;

namespace TownOfHost
{
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.VotingComplete))]
    public static class BlockVotingCompletePatch
    {
        public static bool IsCustomEnding = false;

        public static bool Prefix(MeetingHud __instance)
        {
            // カスタム集計中ならそのままバニラの処理を通す
            if (IsCustomEnding)
            {
                return true;
            }

            // タイマー切れ等でバニラが直接呼んできた場合、
            // 単に処理を殺すのではなく、MOD側のカスタム開票ロジックを強制起動する
            if (AmongUsClient.Instance.AmHost)
            {
                // 例: MOD側の投票集計メソッドを呼んで安全に終わらせる
                // CustomVotingManager.CalculateVotes();
            }

            // バニラ本来の重複・勝手な遷移処理だけを弾く
            return false;
        }
    }
}