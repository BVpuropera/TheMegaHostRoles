using AmongUs.Data;
using AmongUs.GameOptions;
using HarmonyLib;
using System.Collections.Generic;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Neutral;
using UnityEngine;

namespace TownOfHost
{
    class ExileControllerWrapUpPatch
    {
        public static NetworkedPlayerInfo AntiBlackout_LastExiled;

        [HarmonyPatch(typeof(ExileController), nameof(ExileController.WrapUp))]
        class BaseExileControllerPatch
        {
            public static void Postfix(ExileController __instance)
            {
                try
                {
                    WrapUpPostfix(__instance.initData.networkedPlayer);
                }
                finally
                {
                    WrapUpFinalizer(__instance.initData.networkedPlayer);
                }
            }
        }

        [HarmonyPatch(typeof(AirshipExileController), nameof(AirshipExileController.Animate))]
        class AirshipStatusPatch
        {
            public static void Postfix(AirshipExileController __instance, ref Il2CppSystem.Collections.IEnumerator __result)
            {
                // WrapUpAndSpawnに直接パッチが当たらないのでAnimateメソッド中にパッチを当てる
                var pathcer = new CoroutinPatcher(__result);
                // WrapUpAndSpawnはステートマシンとしてクラス化されているためそのクラス実行前にパッチを当てる
                pathcer.AddPrefix(typeof(AirshipExileController._WrapUpAndSpawn_d__11), () =>
                    AirshipExileControllerPatch.Postfix(__instance)
                );
                __result = pathcer.EnumerateWithPatch();
            }
        }

        class AirshipExileControllerPatch
        {
            public static void Postfix(AirshipExileController __instance)
            {
                try
                {
                    WrapUpPostfix(__instance.initData.networkedPlayer);
                }
                finally
                {
                    WrapUpFinalizer(__instance.initData.networkedPlayer);
                }
            }
        }

        static void WrapUpPostfix(NetworkedPlayerInfo exiled)
        {
            if (AntiBlackout.OverrideExiledPlayer)
            {
                exiled = AntiBlackout_LastExiled;
            }

            var mapId = Main.NormalOptions.MapId;
            // エアシップではまだ湧かない
            if ((MapNames)mapId != MapNames.Airship)
            {
                foreach (var state in PlayerState.AllPlayerStates.Values)
                {
                    state.HasSpawned = true;
                }
            }

            bool DecidedWinner = false;
            if (!AmongUsClient.Instance.AmHost) return; // ホスト以外はこれ以降の処理を実行しません
            AntiBlackout.RestoreIsDead(doSend: false);
            if (exiled != null)
            {
                var role = exiled.GetCustomRole();
                var info = role.GetRoleInfo();
                // 霊界用暗転バグ対処
                if (!AntiBlackout.OverrideExiledPlayer && info?.IsDesyncImpostor == true)
                    exiled.Object?.ResetPlayerCam(1f);

                exiled.IsDead = true;
                PlayerState.GetByPlayerId(exiled.PlayerId).DeathReason = CustomDeathReason.Vote;

                foreach (var roleClass in CustomRoleManager.AllActiveRoles.Values)
                {
                    roleClass.OnExileWrapUp(exiled, ref DecidedWinner);
                }

                if (CustomWinnerHolder.WinnerTeam != CustomWinner.Terrorist) PlayerState.GetByPlayerId(exiled.PlayerId).SetDead();
            }

            foreach (var pc in Main.AllPlayerControls)
            {
                pc.ResetKillCooldown();
            }
            if (RandomSpawn.IsRandomSpawn())
            {
                RandomSpawn.SpawnMap map;
                switch (mapId)
                {
                    case 0:
                        map = new RandomSpawn.SkeldSpawnMap();
                        Main.AllPlayerControls.Do(map.RandomTeleport);
                        break;
                    case 1:
                        map = new RandomSpawn.MiraHQSpawnMap();
                        Main.AllPlayerControls.Do(map.RandomTeleport);
                        break;
                    case 2:
                        map = new RandomSpawn.PolusSpawnMap();
                        Main.AllPlayerControls.Do(map.RandomTeleport);
                        break;
                    case 5:
                        map = new RandomSpawn.FungleSpawnMap();
                        Main.AllPlayerControls.Do(map.RandomTeleport);
                        break;
                }
            }
            FallFromLadder.Reset();
            Utils.CountAlivePlayers(true);
            Utils.AfterMeetingTasks();
            if (mapId != 4)
            {
                foreach (var pc in Main.AllPlayerControls)
                {
                    pc.GetRoleClass()?.OnSpawn();
                    pc.SyncSettings();
                    pc.RpcResetAbilityCooldown();
                }
            }
            Utils.NotifyRoles();
        }

        // 引数 (NetworkedPlayerInfo exiled = null) を受け取れるように変更
        public static void WrapUpFinalizer(NetworkedPlayerInfo exiled = null)
        {
            if (AmongUsClient.Instance.AmHost)
            {
                // 1. 会議アニメーション中（2秒後）に AntiBlackout の役職復元を実行
                _ = new LateTask(() =>
                {
                    if (GameStates.IsEnded) return;

                    // ダミー役職から本来の役職・Desync状態（ジキルとハイド等）へ復元
                    AntiBlackout.RevertToActualRoleTypes();

                    // ジキル＆ハイドのターン加算
                    JekyllAndHyde.OnTaskPhaseStart();

                }, 2f, "Revert AntiBlackout Measures");
            }

            GameStates.AlreadyDied |= !Utils.IsAllAlive;
            RemoveDisableDevicesPatch.UpdateDisableDevices();
            SoundManager.Instance.ChangeAmbienceVolume(DataManager.Settings.Audio.AmbienceVolume);

            GameStates.InTask = true;
            Logger.Info("Start task phase", "Phase");

            if (!AmongUsClient.Instance.AmHost || GameStates.IsEnded) return;

            // 2. 役職復元が完了した直後（2.4秒後）に「道連れ死亡・UIリセット」を実行
            _ = new LateTask(() =>
            {
                AfterMeetingTasks();
            }, 2.4f, "Execute AfterMeetingTasks");
        }

        public static void AfterMeetingTasks()
        {
            if (GameStates.IsEnded) return;

            // 追放後死亡（道連れ・道連れ連鎖等）の処理
            foreach (var x in Main.AfterMeetingDeathPlayers)
            {
                var player = Utils.GetPlayerById(x.Key);
                if (player == null) continue;

                var state = PlayerState.GetByPlayerId(x.Key);
                if (state != null)
                {
                    state.DeathReason = x.Value;
                    state.SetDead();
                }
                player.Data.IsDead = true;
            }
            Main.AfterMeetingDeathPlayers.Clear();

            // カメラやUIのリセット
            foreach (var pc in PlayerControl.AllPlayerControls)
            {
                if (pc == null) continue;
                pc.ResetPlayerCam(1f);
            }

            TriggerSafeOverlayRefresh();
            ForceResetLocalHud();

            Logger.Info("AfterMeetingTasks 完了", "ExilePatch");
        }

        private static void TriggerSafeOverlayRefresh()
        {
            if (DestroyableSingleton<HudManager>.Instance == null) return;

            var hud = DestroyableSingleton<HudManager>.Instance;
            if (hud.KillOverlay != null)
            {
                hud.KillOverlay.gameObject.SetActive(true);
                hud.KillOverlay.gameObject.SetActive(false);
            }
        }

        // 自分のPC（ホスト/クライアントローカル）のUIとフェードを直す処理
        private static void ForceResetLocalHud()
        {
            // 1. 開いているすべてのミニゲーム（会議画面含む）を強制的に閉じる
            foreach (var minigame in UnityEngine.Object.FindObjectsOfType<Minigame>())
            {
                if (minigame != null)
                {
                    try
                    {
                        minigame.Close();
                        UnityEngine.Object.Destroy(minigame.gameObject);
                    }
                    catch { }
                }
            }

            // 2. 追放画面の完全破棄
            if (ExileController.Instance != null)
            {
                UnityEngine.Object.Destroy(ExileController.Instance.gameObject);
            }

            // 3. HUDおよび画面フェード（暗転）の強制全解除
            if (DestroyableSingleton<HudManager>.Instance != null)
            {
                var hud = DestroyableSingleton<HudManager>.Instance;

                // HUDアクティブ化
                hud.SetHudActive(true);

                // 画面の暗転（ShadowQuad）を非アクティブ化
                if (hud.ShadowQuad != null)
                {
                    hud.ShadowQuad.gameObject.SetActive(false);
                }

                // カメラのフルカラー/フェード強制解除
                if (hud.FullScreen != null)
                {
                    hud.FullScreen.enabled = false;
                    hud.FullScreen.gameObject.SetActive(false);
                }

                // KillOverlayの描画フラグを一度通して暗転板やUIレイヤーを安全に再構成
                if (hud.KillOverlay != null)
                {
                    hud.KillOverlay.gameObject.SetActive(true);
                    hud.KillOverlay.gameObject.SetActive(false);
                }
            }

            // 4. ローカルプレイヤーの操作ロック・カメラ追従の強制復帰
            if (PlayerControl.LocalPlayer != null)
            {
                // 操作ロック解除
                PlayerControl.LocalPlayer.moveable = true;

                // カメラの追従対象を自プレイヤーに強制再設定
                if (Camera.main != null)
                {
                    var follow = Camera.main.GetComponent<FollowerCamera>();
                    if (follow != null)
                    {
                        follow.Target = PlayerControl.LocalPlayer;
                        follow.Locked = false;
                    }
                }
            }
        }
    }

    [HarmonyPatch(typeof(PbExileController), nameof(PbExileController.PlayerSpin))]
    class PolusExileHatFixPatch
    {
        public static void Prefix(PbExileController __instance)
        {
            __instance.Player.cosmetics.hat.transform.localPosition = new(-0.2f, 0.6f, 1.1f);
        }
    }
}