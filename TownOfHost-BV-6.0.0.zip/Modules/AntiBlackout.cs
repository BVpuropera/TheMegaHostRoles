using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using AmongUs.GameOptions;
using Hazel;
using TownOfHost.Attributes;
using TownOfHost.Modules;
using TownOfHost.Patches;
using TownOfHost.Roles.Core;
using UnityEngine;

namespace TownOfHost
{
    public static class AntiBlackout
    {
        public static bool SkipTasks { get; private set; } = false;
        public static bool IsCached { get; private set; } = false;
        public static bool IsSet { get; private set; } = false;

        // 他のパッチクラス（Disconnect/Exile等）から参照されるプロパティ・メソッドの互換保持
        public static bool OverrideExiledPlayer => false;

        // 会議前の本来のロール状態（SeerID, TargetID -> RoleType）の退避マップ
        private static Dictionary<(byte SeerID, byte TargetID), RoleTypes> cachedRoleMap = new();

        private readonly static LogHandler logger = Logger.Handler("AntiBlackout");

        /// <summary>
        /// 会議終了時、バニラの暗転防止のために最適なダミー役職構成(Imp1人 + Crew)を一時割り当て
        /// </summary>
        public static void SetOptimalRoleTypes()
        {
            if (!AmongUsClient.Instance.AmHost) return;
            if (PlayerControl.AllPlayerControls.Count <= 2) return;

            logger.Info("SetOptimalRoleTypes: 暗転回避用ダミー役職の生成開始");
            SkipTasks = true;
            IsCached = true;
            cachedRoleMap.Clear();

            // 現在の生存者を抽出
            var alivePlayers = PlayerControl.AllPlayerControls.ToArray()
                .Where(pc => pc != null && pc.Data != null && !pc.Data.IsDead && !pc.Data.Disconnected)
                .ToList();

            if (alivePlayers.Count == 0) return;

            // 1. 本来の役職マップを退避（全視点分）
            foreach (var seer in PlayerControl.AllPlayerControls)
            {
                if (seer == null) continue;
                foreach (var target in PlayerControl.AllPlayerControls)
                {
                    if (target == null) continue;

                    RoleTypes originalRole = RoleTypes.Crewmate;
                    if (target.Data != null && target.Data.Role != null)
                    {
                        originalRole = target.Data.Role.Role;
                    }

                    cachedRoleMap[(seer.PlayerId, target.PlayerId)] = originalRole;
                }
            }

            // 2. ダミーインポスターの選定（生存者から1人選出）
            PlayerControl dummyImp = alivePlayers.FirstOrDefault();
            if (dummyImp == null) return;

            // 3. 生存者全員に対して「ダミーインポスター1人」と「ダミークルー」を割り当て送信
            SendRoleRPC(dummyImp.PlayerId, RoleTypes.Impostor);

            foreach (var pc in alivePlayers)
            {
                if (pc.PlayerId == dummyImp.PlayerId) continue;
                SendRoleRPC(pc.PlayerId, RoleTypes.Crewmate);
            }

            SendGameData();
        }

        /// <summary>
        /// 会議画面が明けた後、遅延処理で本来の役職・Desync状態へ完全復元する
        /// </summary>
        public static void RevertToActualRoleTypes()
        {
            if (!AmongUsClient.Instance.AmHost) return;

            if (cachedRoleMap.Count == 0)
            {
                SkipTasks = false;
                IsCached = false;
                return;
            }

            logger.Info("RevertToActualRoleTypes: 本来の役職およびDesync状態への再同期を開始");

            // 1. まずMod上で「生存している」プレイヤーの IsDead フラグを強制的に false に戻す
            foreach (var pc in PlayerControl.AllPlayerControls)
            {
                if (pc == null || pc.Data == null) continue;

                // Mod側の死亡リスト（AfterMeetingDeathPlayersなど）に含まれていないなら生存判定
                bool isModDead = Main.AfterMeetingDeathPlayers.ContainsKey(pc.PlayerId) ||
                                 (PlayerState.GetByPlayerId(pc.PlayerId)?.IsDead ?? false);

                if (!isModDead)
                {
                    pc.Data.IsDead = false; // バニラが勝手に建てた死亡フラグを上書き消元
                }
            }

            // 2. 本来の役職・Desync役職を復元送信
            foreach (var targetGroup in cachedRoleMap.GroupBy(x => x.Key.TargetID))
            {
                byte targetId = targetGroup.Key;
                var target = Utils.GetPlayerById(targetId);
                if (target == null || target.Data == null) continue;

                RoleTypes defaultRole = targetGroup.FirstOrDefault().Value;
                SendRoleRPC(targetId, defaultRole);

                foreach (var entry in targetGroup)
                {
                    byte seerId = entry.Key.SeerID;
                    RoleTypes desyncRole = entry.Value;

                    if (desyncRole != defaultRole)
                    {
                        SendDesyncRoleRPC(targetId, seerId, desyncRole);
                    }
                }
            }

            cachedRoleMap.Clear();

            // 3. 生存フラグ(IsDead = false)を書き換えた全プレイヤーの GameData(0x05) パケットを一斉送信！
            SendGameData();

            SkipTasks = false;
            IsCached = false;
            logger.Info("RevertToActualRoleTypes: 生存フラグ補正＆役職再同期完了");
        }

        // --- 内部RPC送信ヘルパー ---

        private static void SendRoleRPC(byte playerId, RoleTypes role)
        {
            var pc = Utils.GetPlayerById(playerId);
            if (pc == null || pc.Data == null) return;

            // ホストローカルのデータ更新
            if (pc.Data.Role != null)
            {
                pc.Data.Role.Role = role;
            }

            // 全クライアントへ SetRole (0x02) RPCを実際に一斉送信する
            try
            {
                MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(pc.NetId, (byte)RpcCalls.SetRole, SendOption.Reliable, -1);
                writer.Write((ushort)role);
                AmongUsClient.Instance.FinishRpcImmediately(writer);
            }
            catch (Exception ex)
            {
                logger.Warn($"SendRoleRPC 送信失敗 (PlayerID: {playerId}): {ex.Message}");
            }
        }

        private static void SendDesyncRoleRPC(byte targetId, byte seerId, RoleTypes role)
        {
            var target = Utils.GetPlayerById(targetId);
            var seer = Utils.GetPlayerById(seerId);
            if (target == null || seer == null) return;

            try
            {
                MessageWriter writer = AmongUsClient.Instance.StartRpcImmediately(target.NetId, (byte)RpcCalls.SetRole, SendOption.Reliable, seer.GetClientId());
                writer.Write((ushort)role);
                AmongUsClient.Instance.FinishRpcImmediately(writer);
            }
            catch (Exception ex)
            {
                logger.Warn($"SendDesyncRoleRPC 例外発生: {ex.Message}");
            }
        }

        public static void SendGameData([CallerMemberName] string callerMethodName = "")
        {
            logger.Info($"SendGameData is called from {callerMethodName}");
            if (GameData.Instance == null) return;

            foreach (var playerinfo in GameData.Instance.AllPlayers)
            {
                if (playerinfo == null) continue;
                MessageWriter writer = MessageWriter.Get(SendOption.Reliable);
                writer.StartMessage(5); // 0x05 GameData
                {
                    writer.Write(AmongUsClient.Instance.GameId);
                    writer.StartMessage(1); // 0x01 Data
                    {
                        writer.WritePacked(playerinfo.NetId);
                        playerinfo.Serialize(writer, true);
                    }
                    writer.EndMessage();
                }
                writer.EndMessage();

                AmongUsClient.Instance.SendOrDisconnect(writer);
                writer.Recycle();
            }
        }

        // --- 外部パッチ呼び出し用の互換メンバー ---

        public static void FixLivingPlayersState()
        {
            // 生存者同期用ラップ（必要に応じて記述）
        }

        public static void OnDisconnect(NetworkedPlayerInfo player)
        {
            if (!AmongUsClient.Instance.AmHost || player == null || !player.Disconnected) return;
            player.IsDead = player.Disconnected = !OverrideExiledPlayer;
            SendGameData();
        }

        public static void SetIsDead(bool doSend = true, [CallerMemberName] string callerMethodName = "")
        {
            SetOptimalRoleTypes();
        }

        public static void RestoreIsDead(bool doSend = true, [CallerMemberName] string callerMethodName = "")
        {
            RevertToActualRoleTypes();
        }

        [GameModuleInitializer]
        public static void Reset()
        {
            logger.Info("==Reset==");
            cachedRoleMap.Clear();
            SkipTasks = false;
            IsCached = false;
            IsSet = false;
        }
    }
}