using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using AmongUs.GameOptions;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using UnityEngine;

using TownOfHost.Attributes;
using TownOfHost.Roles.Core;
using TownOfHost.Modules;

/*  役職名→Info→提案者名 (InfoLong)
ハッカー;0 こんなこと、朝飯前さ;1 澄水巡（Sumizu Meguru）;2 (クルー陣営。タスクをすべて終わらせると一人だけ役職を見ることができる。);3
ブラックハッカー;0 おっと、ここがら空きだぜ？;1 澄水巡（Sumizu Meguru）;2 (第三陣営。最初から全員の陣営が分かっている。（第三陣営の場合役職が表示される。）タスクをすべて終わらせているかつ生存していた場合乗っ取り勝利。);3
海賊王;0 俺の財宝か？欲しけりゃくれてやる...;1 ゆららん（Yuraran）;2 (第三陣営。タスクをすべて終わらせ、追放された場合乗っ取り勝利。);3
*/

//YouTuberさん、VTuberさんが役職提案してくれたのでチャンネルを紹介します！
//@yuraranYR
//@Sumizumeguru