using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using AmongUs.GameOptions;
using Hazel;
using TownOfHost.Attributes;
using TownOfHost.Modules;
using TownOfHost.Roles.Core;

namespace TownOfHost
{
    public static class AntiBlackout
    {
        public static bool IsCached { get; private set; } = false;
        public static bool IsSet { get; private set; } = false;
        public static bool Iswaitsend { get; private set; } = false;
        public static byte dummyImpostorPlayer { get; private set; } = byte.MaxValue;
        public static System.Collections.Generic.Dictionary<byte, (bool isDead, bool Disconnected)> isDeadCache = new();
        public static System.Collections.Generic.List<byte> isRoleCache = new();

        private readonly static LogHandler logger = Logger.Handler("AntiBlackout");

        private static bool GetA()
        {
            foreach (var (role, info) in CustomRoleManager.AllRolesInfo)
                if (info.IsEnable && info.CountType is not CountTypes.Crew and not CountTypes.Impostor)
                    return true;
            return false;
        }

        public static bool OverrideExiledPlayer
        {
            get
            {
                if (4 <= PlayerControl.AllPlayerControls.Count) return false;
                return (Options.NoGameEnd.GetBool() || GetA());
            }
        }

        // 💡 提案された SetRole ロジックを綺麗に統合
        public static void SetRole()
        {
            if (!AmongUsClient.Instance.AmHost) return;

            isRoleCache.Clear();
            IsSet = true;
            Iswaitsend = true;

            // ダミーのインポスターIDを決定（ホスト自身）
            byte ImpostorId = PlayerControl.LocalPlayer.PlayerId;
            dummyImpostorPlayer = ImpostorId;

            foreach (var player in PlayerControl.AllPlayerControls)
            {
                isRoleCache.Add(player.PlayerId);
            }

            // ホストから各クライアントへ、暗転を防ぐためのバニラ役職（Crewmate / Impostor）を同期
            foreach (var target in PlayerControl.AllPlayerControls)
            {
                if (target == null || target.Data.Disconnected) continue;

                // 💡 TOH本家の標準RPCメソッドを使用してバニラ役職を強制同期し、クライアント側の暗転を回避
                target.RpcSetRole(target.Data.Role.IsImpostor ? RoleTypes.Impostor : RoleTypes.Crewmate);
            }
        }

        public static void SetIsDead(bool doSend = true, [CallerMemberName] string callerMethodName = "")
        {
            logger.Info($"SetIsDead is called from {callerMethodName}");
            if (IsCached) return;

            // 会議中、または投票フェーズ中なら生存偽装の処理自体をスキップする
            if (AmongUsClient.Instance.AmHost && MeetingHud.Instance != null)
            {
                logger.Info("会議中のため、SetIsDeadの偽装処理をスキップします。");
                return;
            }

            isDeadCache.Clear();
            var nowcount = PlayerControl.AllPlayerControls.Count;
            foreach (var info in GameData.Instance.AllPlayers)
            {
                if (info == null) continue;
                if (info.IsDead) continue;

                isDeadCache[info.PlayerId] = (info.IsDead, info.Disconnected);
                if ((info.Disconnected == true) && 4 <= nowcount) continue;
                info.IsDead = false;
                info.Disconnected = false;
            }
            IsCached = true;
            if (doSend) SendGameData();
        }

        public static void RestoreIsDead(bool doSend = true, [CallerMemberName] string callerMethodName = "")
        {
            logger.Info($"RestoreIsDead is called from {callerMethodName}");
            foreach (var info in GameData.Instance.AllPlayers)
            {
                if (info == null) continue;
                if (!isDeadCache.ContainsKey(info.PlayerId)) continue;

                if (isDeadCache.TryGetValue(info.PlayerId, out var val))
                {
                    info.IsDead = val.isDead;
                    info.Disconnected = val.Disconnected;
                }
            }
            isDeadCache.Clear();
            IsCached = false;
            IsSet = false;

            // 💡 偽装解除時、全員の役職リセットとクールダウン等の復元を一斉に行う
            foreach (var player in PlayerControl.AllPlayerControls)
            {
                if (player == null) continue;
                ResetSetRole(player);
            }

            if (doSend) SendGameData();
        }

        public static void SendGameData([CallerMemberName] string callerMethodName = "")
        {
            logger.Info($"SendGameData is called from {callerMethodName}");
            foreach (var playerinfo in GameData.Instance.AllPlayers)
            {
                if (playerinfo == null) continue;
                MessageWriter writer = MessageWriter.Get(SendOption.Reliable);
                writer.StartMessage(5); //0x05 GameData
                {
                    writer.Write(AmongUsClient.Instance.GameId);
                    writer.StartMessage(1); //0x01 Data
                    {
                        writer.WritePacked(playerinfo.NetId);
                        playerinfo.Serialize(writer, true);
                    }
                    writer.EndMessage();
                }
                writer.EndMessage();

                AmongUsClient.Instance.SendOrDisconnect(writer);
                writer.Recycle();
            }
        }

        public static void OnDisconnect(NetworkedPlayerInfo player)
        {
            if (player == null) return;
            if (!AmongUsClient.Instance.AmHost || !IsCached || !player.Disconnected) return;
            isDeadCache[player.PlayerId] = (true, true);
            player.IsDead = player.Disconnected = !OverrideExiledPlayer;
            SendGameData();
        }

        public static void ResetSetRole(PlayerControl player)
        {
            if (player == null) return;
            dummyImpostorPlayer = byte.MaxValue;
            isRoleCache.Remove(player.PlayerId);

            player.ResetKillCooldown();
            player.SetKillCooldown();

            try
            {
                ExtendedPlayerControl.RpcResetAbilityCooldown(player);
            }
            catch { }

            if (!player.IsAlive())
            {
                player.Exiled();
            }
        }

        public static void TempRestore(Action action)
        {
            logger.Info("==Temp Restore==");
            bool before_IsCached = IsCached;
            try
            {
                if (before_IsCached) RestoreIsDead(doSend: false);
                action();
            }
            catch (Exception ex)
            {
                logger.Warn("AntiBlackout.TempRestore内で例外が発生しました");
                logger.Exception(ex);
            }
            finally
            {
                if (before_IsCached) SetIsDead(doSend: false);
                logger.Info("==/Temp Restore==");
            }
        }

        [GameModuleInitializer]
        public static void Reset()
        {
            logger.Info("==Reset==");
            if (isDeadCache == null) isDeadCache = new();
            if (isRoleCache == null) isRoleCache = new();
            isRoleCache.Clear();
            isDeadCache.Clear();
            IsCached = false;
            Iswaitsend = false;
            IsSet = false;
            dummyImpostorPlayer = byte.MaxValue;
        }
    }
}