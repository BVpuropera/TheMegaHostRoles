using System.Collections.Generic;
using System.Linq;
using System.Text;
using HarmonyLib;
using TownOfHost;
using TownOfHost.Modules;
using TownOfHost.Roles;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using TownOfHost.Roles.Neutral;
using UnityEngine;
using static TownOfHost.Translator;

namespace TownOfHost;

[HarmonyPatch]
public static class MeetingHudPatch
{
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.CheckForEndVoting))]
    class CheckForEndVotingPatch
    {
        public static bool Prefix()
        {
            if (!AmongUsClient.Instance.AmHost) return true;
            MeetingVoteManager.Instance?.CheckAndEndMeeting();
            return false;
        }
    }
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.CastVote))]
    public static class CastVotePatch
    {
        public static bool Prefix(MeetingHud __instance, [HarmonyArgument(0)] byte srcPlayerId /* 投票した人 */ , [HarmonyArgument(1)] byte suspectPlayerId /* 投票された人 */ )
        {
            var voter = Utils.GetPlayerById(srcPlayerId);
            var voted = Utils.GetPlayerById(suspectPlayerId);
            if (voter.GetRoleClass()?.CheckVoteAsVoter(voted) == false)
            {
                __instance.RpcClearVote(voter.GetClientId());
                Logger.Info($"{voter.GetNameWithRole()} は投票しない", nameof(CastVotePatch));
                return false;
            }

            MeetingVoteManager.Instance?.SetVote(srcPlayerId, suspectPlayerId);
            return true;
        }
    }
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.Start))]
    class StartPatch
    {
        public static void Prefix()
        {
            Logger.Info("------------会議開始------------", "Phase");

            // 💡 【重要】会議開始の瞬間に生存偽装を解除し、バニラの正しいデータに戻す！
            // これにより、誰か1人が投票した瞬間に会議が終わるバグと、矛盾による暗転をブロックします。
            if (AmongUsClient.Instance.AmHost)
            {
                AntiBlackout.RestoreIsDead(doSend: true);
            }

            ChatUpdatePatch.DoBlockChat = true;
            GameStates.AlreadyDied |= !Utils.IsAllAlive;
            Main.AllPlayerControls.Do(x => ReportDeadBodyPatch.WaitReport[x.PlayerId].Clear());
            MeetingStates.MeetingCalled = true;
        }
        public static void Postfix(MeetingHud __instance)
        {
            MeetingVoteManager.Start();

            SoundManager.Instance.ChangeAmbienceVolume(0f);
            if (!GameStates.IsModHost) return;
            var myRole = PlayerControl.LocalPlayer.GetRoleClass();
            foreach (var pva in __instance.playerStates)
            {
                var pc = Utils.GetPlayerById(pva.TargetPlayerId);
                if (pc == null) continue;
                var roleTextMeeting = UnityEngine.Object.Instantiate(pva.NameText);
                roleTextMeeting.transform.SetParent(pva.NameText.transform);
                roleTextMeeting.transform.localPosition = new Vector3(0f, -0.18f, 0f);
                roleTextMeeting.fontSize = 1.5f;
                (roleTextMeeting.enabled, roleTextMeeting.text)
                    = Utils.GetRoleNameAndProgressTextData(PlayerControl.LocalPlayer, pc);
                roleTextMeeting.gameObject.name = "RoleTextMeeting";
                roleTextMeeting.enableWordWrapping = false;

                // 役職とサフィックスを同時に表示する必要が出たら要改修
                var suffixBuilder = new StringBuilder(32);
                if (myRole != null)
                {
                    suffixBuilder.Append(myRole.GetSuffix(PlayerControl.LocalPlayer, pc, isForMeeting: true));
                }
                suffixBuilder.Append(CustomRoleManager.GetSuffixOthers(PlayerControl.LocalPlayer, pc, isForMeeting: true));
                if (suffixBuilder.Length > 0)
                {
                    roleTextMeeting.text = suffixBuilder.ToString();
                    roleTextMeeting.enabled = true;
                }
            }
            CustomRoleManager.AllActiveRoles.Values.Do(role => role.OnStartMeeting());
            if (Options.SyncButtonMode.GetBool())
            {
                Utils.SendMessage(string.Format(GetString("Message.SyncButtonLeft"), Options.SyncedButtonCount.GetFloat() - Options.UsedButtonCount));
                Logger.Info("緊急会議ボタンはあと" + (Options.SyncedButtonCount.GetFloat() - Options.UsedButtonCount) + "回使用可能です。", "SyncButtonMode");
            }
            if (AntiBlackout.OverrideExiledPlayer)
            {
                Utils.SendMessage(GetString("Warning.OverrideExiledPlayer"));
            }
            if (MeetingStates.FirstMeeting) TemplateManager.SendTemplate("OnFirstMeeting", noErr: true);
            TemplateManager.SendTemplate("OnMeeting", noErr: true);

            if (AmongUsClient.Instance.AmHost)
            {
                _ = new LateTask(() =>
                {
                    foreach (var seer in Main.AllPlayerControls)
                    {
                        if (seer.IsModClient()) continue;
                        var sender = CustomRpcSender.Create("SetNameToChat", Hazel.SendOption.Reliable);
                        sender.StartMessage(seer.GetClientId());

                        foreach (var seen in Main.AllPlayerControls)
                        {
                            var seenName = seen.GetRealName(isMeeting: true);
                            var coloredName = Utils.ColorString(seen.GetRoleColor(), seenName);
                            sender.RpcSetName(seen, seer == seen ? coloredName : seenName, seer);
                        }
                        sender.SendMessage();
                    }
                    ChatUpdatePatch.DoBlockChat = false;
                }, 3f, "SetName To Chat");
            }

            foreach (var pva in __instance.playerStates)
            {
                if (pva == null) continue;
                var seer = PlayerControl.LocalPlayer;
                var seerRole = seer.GetRoleClass();

                var target = Utils.GetPlayerById(pva.TargetPlayerId);
                if (target == null) continue;

                var sb = new StringBuilder();

                //会議画面での名前変更
                //自分自身の名前の色を変更
                //NameColorManager準拠 of 処理
                pva.NameText.text = pva.NameText.text.ApplyNameColorData(seer, target, true);

                //とりあえずSnitchは会議中にもインポスターを確認することができる仕様にしていますが、変更する可能性があります。

                if (seer.KnowDeathReason(target))
                    sb.Append($"({Utils.ColorString(Utils.GetRoleColor(CustomRoles.Doctor), Utils.GetVitalText(target.PlayerId))})");

                sb.Append(seerRole?.GetMark(seer, target, true));
                sb.Append(CustomRoleManager.GetMarkOthers(seer, target, true));

                foreach (var subRole in target.GetCustomSubRoles())
                {
                    switch (subRole)
                    {
                        case CustomRoles.Lovers:
                            if (seer.Is(CustomRoles.Lovers) || seer.Data.IsDead)
                                sb.Append(Utils.ColorString(Utils.GetRoleColor(CustomRoles.Lovers), "♡"));
                            break;
                    }
                }

                //会議画面ではインポスター自身の名前にSnitchマークはつけません。

                pva.NameText.text += sb.ToString();
            }
        }
    }
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.Update))]
    class UpdatePatch
    {
        public static void Postfix(MeetingHud __instance)
        {
            if (!AmongUsClient.Instance.AmHost) return;
            if (Input.GetMouseButtonUp(1) && Input.GetKey(KeyCode.LeftControl))
            {
                __instance.playerStates.DoIf(x => x.HighlightedFX.enabled, x =>
                {
                    var player = Utils.GetPlayerById(x.TargetPlayerId);
                    player.RpcExile();
                    var state = PlayerState.GetByPlayerId(player.PlayerId);
                    state.DeathReason = CustomDeathReason.Execution;
                    state.SetDead();
                    Utils.SendMessage(string.Format(GetString("Message.Executed"), player.Data.PlayerName));
                    Logger.Info($"{player.GetNameWithRole()}を処刑しました", "Execution");
                    __instance.CheckForEndVoting();
                });
            }
        }
    }
    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.OnDestroy))]
    class OnDestroyPatch
    {
        public static bool IsTransitioning = false;
        public static bool IsAntiFlashTransitioning = false; // 💡 これを新しく追加！

        public static void Postfix()
        {
            MeetingStates.FirstMeeting = false;
            IsTransitioning = true;
            IsAntiFlashTransitioning = true; // 💡 会議終了でフラグON
            Logger.Info("------------会議終了------------", "Phase");

            if (AmongUsClient.Instance.AmHost)
            {
                _ = new LateTask(() =>
                {
                    Logger.Info("[AntiBlackout] 通常フィールド復帰タイミングで生存偽装を適用します。", "AntiBlackout");
                    AntiBlackout.SetIsDead();
                    IsTransitioning = false;
                    IsAntiFlashTransitioning = false; // 💡 ホスト側のフラグ解除
                }, 3.5f, "Apply AntiBlackout Final Sync");
            }
            else
            {
                _ = new LateTask(() => {
                    IsTransitioning = false;
                    IsAntiFlashTransitioning = false; // 💡 クライアント側のフラグ解除
                }, 4.0f, "Clear Client Transition Flag");
            }

            MeetingVoteManager.Instance?.Destroy();
        }
    }

    public static void TryAddAfterMeetingDeathPlayers(CustomDeathReason deathReason, params byte[] playerIds)
    {
        var AddedIdList = new List<byte>();
        foreach (var playerId in playerIds)
            if (Main.AfterMeetingDeathPlayers.TryAdd(playerId, deathReason))
                AddedIdList.Add(playerId);
        CheckForDeathOnExile(deathReason, AddedIdList.ToArray());
    }
    public static void CheckForDeathOnExile(CustomDeathReason deathReason, params byte[] playerIds)
    {
        foreach (var playerId in playerIds)
        {
            //Loversの後追い
            if (CustomRoles.Lovers.IsPresent() && !Main.isLoversDead && Main.LoversPlayers.Find(lp => lp.PlayerId == playerId) != null)
                FixedUpdatePatch.LoversSuicide(playerId, true);
            //道連れチェック
            RevengeOnExile(playerId, deathReason);
        }
    }
    private static void RevengeOnExile(byte playerId, CustomDeathReason deathReason)
    {
        var player = Utils.GetPlayerById(playerId);
        if (player == null) return;
        var target = PickRevengeTarget(player, deathReason);
        if (target == null) return;
        TryAddAfterMeetingDeathPlayers(CustomDeathReason.Revenge, target.PlayerId);
        target.SetRealKiller(player);
        Logger.Info($"{player.GetNameWithRole()}の道連れ先:{target.GetNameWithRole()}", "RevengeOnExile");
    }
    private static PlayerControl PickRevengeTarget(PlayerControl exiledplayer, CustomDeathReason deathReason)//道連れ先選定
    {
        List<PlayerControl> TargetList = new();
        if (exiledplayer.GetRoleClass() is INekomata nekomata)
        {
            // 道連れしない状態ならnull
            if (!nekomata.DoRevenge(deathReason))
            {
                return null;
            }
            TargetList = Main.AllAlivePlayerControls.Where(candidate => candidate != exiledplayer && !Main.AfterMeetingDeathPlayers.ContainsKey(candidate.PlayerId) && nekomata.IsCandidate(candidate)).ToList();
        }
        else
        {
            var isMadmate =
    exiledplayer.Is(CustomRoleTypes.Madmate) ||
    // マッド属性化時に削除
    (exiledplayer.GetRoleClass() is SchrodingerCat schrodingerCat && schrodingerCat.AmMadmate);
            foreach (var candidate in Main.AllAlivePlayerControls)
            {
                if (candidate == exiledplayer || Main.AfterMeetingDeathPlayers.ContainsKey(candidate.PlayerId)) continue;
                switch (exiledplayer.GetCustomRole())
                {
                    // ここにINekomata未適用の道連れ役職を追加
                    default:
                        if (isMadmate && deathReason == CustomDeathReason.Vote && Options.MadmateRevengeCrewmate.GetBool() //黒猫オプション
                        && !candidate.Is(CustomRoleTypes.Impostor))
                            TargetList.Add(candidate);
                        break;
                }
            }
        }
        if (TargetList == null || TargetList.Count == 0) return null;
        var rand = IRandom.Instance;
        var target = TargetList[rand.Next(TargetList.Count)];
        return target;
    }
}

[HarmonyPatch(typeof(PlayerVoteArea), nameof(PlayerVoteArea.SetHighlighted))]
class SetHighlightedPatch
{
    public static bool Prefix(PlayerVoteArea __instance, bool value)
    {
        if (!AmongUsClient.Instance.AmHost) return true;
        if (!__instance.HighlightedFX) return false;
        __instance.HighlightedFX.enabled = value;
        return false;
    }
}

// =================================================================
// 💡 条件を極限まで絞り込み、投票画面への干渉を排除した修正版
// =================================================================
public static class SafeAntiKillFlashPatch
{
    public static bool IsMeetingActive = false;
    public static bool IsInTransition = false;

    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.Start))]
    [HarmonyPostfix]
    public static void Postfix_MeetingStart()
    {
        IsMeetingActive = true;
        IsInTransition = false;
    }

    [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.CheckForEndVoting))]
    [HarmonyPostfix]
    public static void Postfix_MeetingEndCheck()
    {
        IsMeetingActive = false;
        IsInTransition = true;

        // 💡 会議明けの画面ロック強制解除タスク
        _ = new TownOfHost.LateTask(() => {

            IsInTransition = false; // ←次の会議のためにフラグを必ず戻す

            Logger.Info("[ScreenFix] 画面のロック解除とUIの再描画更新を試みます。", "Fix");

            MeetingHud meetingHud = MeetingHud.Instance;
            HudManager hudManager = DestroyableSingleton<HudManager>.Instance;

            if (hudManager != null)
            {
                // 1. 真っ黒な画面の元凶であるシャドウクアッドを強制OFF
                if (hudManager.ShadowQuad != null)
                {
                    hudManager.ShadowQuad.gameObject.SetActive(false);
                }

                // 2. フルスクリーン効果オブジェクトを安全に無効化
                var fadeEffect = hudManager.transform.Find("FullScreenEffect")?.gameObject;
                if (fadeEffect != null)
                {
                    fadeEffect.SetActive(false);
                }
            }

            if (meetingHud != null && meetingHud.playerStates != null)
            {
                // 3. マスクエリアを一旦OFFにして即座にONに戻す（描画状態の強制リフレッシュ）
                try
                {
                    foreach (var state in meetingHud.playerStates)
                    {
                        if (state?.MaskArea != null)
                        {
                            state.MaskArea.gameObject.SetActive(false);
                            state.MaskArea.gameObject.SetActive(true); // ←即座に戻してフリーズを防ぐ
                        }
                    }
                }
                catch { }
            }
        }, 3.5f, "ScreenResetTask");
    }

    [HarmonyPatch(typeof(HudManager), "KillFlash")]
    [HarmonyPrefix]
    public static bool Prefix_BlockKillFlash()
    {
        // ⚠️ MeetingHud.Instance != null などの過剰な条件を削除！
        // 純粋に「会議終了直後の遷移中（IsInTransition）」のピンポイントの瞬間だけブロックする
        if (IsInTransition)
        {
            Logger.Info("[AntiAntiFlash] 会議終了直後のため、キルフラッシュをブロックしました。", "Fix");
            return false;
        }

        return true;
    }
}