using System;
using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using TownOfHost.Attributes;
using TownOfHost.Roles.Core;
using UnityEngine;

namespace TownOfHost
{
    public class KatagakiKaihou
    {
        // サーバー側のローカルに保存するファイルパス
        private static readonly string SaveFilePath = Path.Combine(Application.persistentDataPath, "unlocked_titles.txt");

        // プレイヤーの固有IDごとに、解放済み称号キーのリストを保持する辞書
        public static Dictionary<string, HashSet<string>> PlayerUnlockedTitles = new();

        // プレイヤー名（またはID）と、現在セットしている称号の辞書
        public static Dictionary<string, string> ActiveTitles = new();

        // 内部キーから表示名へのマッピング
        public static readonly Dictionary<string, string> TitleDisplayNames = new()
        {
            { "None", "(称号なし)" },
            { "longdream", "長き夢" },
            { "Portal2", "ポータル" },
            { "slashflash", "一閃" },
            { "100", "依頼成功率:100%" },
            { "Jester", "処刑台に踊る道化" }
        };

        [GameModuleInitializer]
        public static void Reset()
        {
            LoadPlayerData();
            ActiveTitles.Clear(); // ロビーリセット時に選択中称号もクリア
        }

        // 称号を新しく解放して保存するメソッド
        public static void UnlockTitle(PlayerControl player, string titleKey)
        {
            if (player == null || player.Data.Disconnected) return;

            string playerKey = player.name;
            if (string.IsNullOrEmpty(playerKey)) playerKey = player.Data.PlayerName;

            if (!PlayerUnlockedTitles.ContainsKey(playerKey))
            {
                PlayerUnlockedTitles[playerKey] = new HashSet<string>();
            }

            // まだ解放されていない称号だったら追加して保存
            if (PlayerUnlockedTitles[playerKey].Add(titleKey))
            {
                SavePlayerData();

                // チャットで解放メッセージを通知
                string displayName = TitleDisplayNames.TryGetValue(titleKey, out var name) ? name : titleKey;
                string msg = $"<color=#FFD700>{player.Data.PlayerName}</color> が称号「<color=#FF6633>{displayName}</color>」を解放しました！";

                // TOHのシステムチャット送信
                Utils.SendMessage(msg);
            }
        }

        // セーブデータの保存
        private static void SavePlayerData()
        {
            try
            {
                List<string> lines = new();
                foreach (var kvp in PlayerUnlockedTitles)
                {
                    string titles = string.Join(",", kvp.Value);
                    lines.Add($"{kvp.Key}:{titles}");
                }
                File.WriteAllLines(SaveFilePath, lines);
            }
            catch (Exception ex)
            {
                // 💡 エラーログをUnityの標準デバッグ出力にしてエラーを回避
                Debug.LogError($"[TitleUnlock] 称号データの保存に失敗しました: {ex.Message}");
            }
        }

        // セーブデータの読み込み
        private static void LoadPlayerData()
        {
            PlayerUnlockedTitles.Clear();
            if (!File.Exists(SaveFilePath)) return;

            try
            {
                string[] lines = File.ReadAllLines(SaveFilePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(':');
                    if (parts.Length < 2) continue;

                    string playerKey = parts[0];
                    string[] titles = parts[1].Split(',');

                    PlayerUnlockedTitles[playerKey] = new HashSet<string>(titles);
                }
            }
            catch (Exception ex)
            {
                // 💡 エラーログをUnityの標準デバッグ出力にしてエラーを回避
                Debug.LogError($"[TitleUnlock] 称号データの読み込みに失敗しました: {ex.Message}");
            }
        }
    }

    // 💡 ネームタグへの描画処理を安定化させるパッチ
    // 💡 勝利者が決定した瞬間にパッチを当てる（より安全なフック方式）
    [HarmonyPatch(typeof(CustomWinnerHolder), nameof(CustomWinnerHolder.ShiftWinnerAndSetWinner))]
    class TitleWinnerPatch
    {
        public static void Postfix(CustomWinner winner)
        {
            // ホスト側だけで実行するガード
            if (!AmongUsClient.Instance.AmHost) return;

            // 勝者リストを安全に取得
            var winnerIds = CustomWinnerHolder.WinnerIds;
            if (winnerIds == null || winnerIds.Count == 0) return;

            // 💡 修正点：初期値を設定せず、ループ内で最初に見つかった役職を代入する
            string titleKey = "";

            foreach (byte firstWinnerId in winnerIds)
            {
                var firstPlayer = Utils.GetPlayerById(firstWinnerId);
                if (firstPlayer != null)
                {
                    CustomRoles winningRole = firstPlayer.GetCustomRole();

                    // 💡 見つかった役職に応じてキーを判定
                    if (winningRole == CustomRoles.Sleeper) titleKey = "longdream";
                    else if (winningRole == CustomRoles.GateKiller) titleKey = "Portal2";
                    else if (winningRole == CustomRoles.Cannon) titleKey = "100";
                    else if (winningRole == CustomRoles.Samurai) titleKey = "slashflash";
                    else if (winningRole == CustomRoles.Jester) titleKey = "Jester";

                    break; // 1人分の判定が終わったらループを抜ける
                }
            }

            // 対象のカスタム役職の勝利じゃない場合は何もしない
            if (string.IsNullOrEmpty(titleKey)) return;

            // 勝者リストに入っている全員を処理
            foreach (byte winnerId in winnerIds)
            {
                var player = Utils.GetPlayerById(winnerId);
                if (player == null) continue;

                // 確実に称号を解放！
                KatagakiKaihou.UnlockTitle(player, titleKey);
            }
        }
    }
}