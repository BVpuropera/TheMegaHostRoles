using AmongUs.Data;
using HarmonyLib;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Neutral;
using System;

namespace TownOfHost
{
    // =================================================================
    // 💡 外部からの古い参照を維持するブリッジ
    // =================================================================
    public static class ExileControllerWrapUpPatch
    {
        public static NetworkedPlayerInfo AntiBlackout_LastExiled
        {
            get => ExilePatchSharedLogic.AntiBlackout_LastExiled;
            set => ExilePatchSharedLogic.AntiBlackout_LastExiled = value;
        }
    }

    // =================================================================
    // 💡 階層構造（ネスト）を解消したトップレベルのパッチ群
    // =================================================================
    [HarmonyPatch(typeof(ExileController), nameof(ExileController.WrapUp))]
    public static class BaseExileControllerPatch
    {
        public static void Postfix(ExileController __instance)
        {
            try
            {
                ExilePatchSharedLogic.WrapUpPostfix(__instance.initData.networkedPlayer);
            }
            finally
            {
                ExilePatchSharedLogic.WrapUpFinalizer(__instance.initData.networkedPlayer);
            }
        }
    }

    [HarmonyPatch(typeof(AirshipExileController), nameof(AirshipExileController.Animate))]
    public static class AirshipStatusPatch
    {
        public static void Postfix(AirshipExileController __instance, ref Il2CppSystem.Collections.IEnumerator __result)
        {
            var patcher = new CoroutinPatcher(__result);
            patcher.AddPrefix(typeof(AirshipExileController._WrapUpAndSpawn_d__11), () =>
                AirshipExileControllerPatch.Postfix(__instance)
            );
            __result = patcher.EnumerateWithPatch();
        }
    }

    public static class AirshipExileControllerPatch
    {
        public static void Postfix(AirshipExileController __instance)
        {
            try
            {
                ExilePatchSharedLogic.WrapUpPostfix(__instance.initData.networkedPlayer);
            }
            finally
            {
                ExilePatchSharedLogic.WrapUpFinalizer(__instance.initData.networkedPlayer);
            }
        }
    }

    [HarmonyPatch(typeof(PbExileController), nameof(PbExileController.PlayerSpin))]
    public static class PolusExileHatFixPatch
    {
        public static void Prefix(PbExileController __instance)
        {
            if (__instance.Player?.cosmetics?.hat != null)
            {
                __instance.Player.cosmetics.hat.transform.localPosition = new(-0.2f, 0.6f, 1.1f);
            }
        }
    }

    // =================================================================
    // 💡 メインロジック（安全化・最適化版）
    // =================================================================
    public static class ExilePatchSharedLogic
    {
        public static NetworkedPlayerInfo AntiBlackout_LastExiled;

        public static void WrapUpPostfix(NetworkedPlayerInfo exiled)
        {
            if (AntiBlackout.OverrideExiledPlayer)
            {
                exiled = AntiBlackout_LastExiled;
            }

            var mapId = Main.NormalOptions.MapId;
            if ((MapNames)mapId != MapNames.Airship)
            {
                foreach (var state in PlayerState.AllPlayerStates.Values)
                {
                    state.HasSpawned = true;
                }
            }

            bool DecidedWinner = false;
            if (!AmongUsClient.Instance.AmHost) return;

            AntiBlackout.RestoreIsDead(doSend: false);
            if (exiled != null)
            {
                var role = exiled.GetCustomRole();
                var info = role.GetRoleInfo();

                if (!AntiBlackout.OverrideExiledPlayer && info?.IsDesyncImpostor == true)
                    exiled.Object?.ResetPlayerCam(1f);

                exiled.IsDead = true;
                PlayerState.GetByPlayerId(exiled.PlayerId).DeathReason = CustomDeathReason.Vote;

                foreach (var roleClass in CustomRoleManager.AllActiveRoles.Values)
                {
                    roleClass.OnExileWrapUp(exiled, ref DecidedWinner);
                }

                if (CustomWinnerHolder.WinnerTeam != CustomWinner.Terrorist)
                    PlayerState.GetByPlayerId(exiled.PlayerId).SetDead();
            }

            foreach (var pc in Main.AllPlayerControls)
            {
                pc.ResetKillCooldown();
            }

            if (RandomSpawn.IsRandomSpawn())
            {
                RandomSpawn.SpawnMap map;
                switch (mapId)
                {
                    case 0: map = new RandomSpawn.SkeldSpawnMap(); Main.AllPlayerControls.Do(map.RandomTeleport); break;
                    case 1: map = new RandomSpawn.MiraHQSpawnMap(); Main.AllPlayerControls.Do(map.RandomTeleport); break;
                    case 2: map = new RandomSpawn.PolusSpawnMap(); Main.AllPlayerControls.Do(map.RandomTeleport); break;
                    case 5: map = new RandomSpawn.FungleSpawnMap(); Main.AllPlayerControls.Do(map.RandomTeleport); break;
                }
            }

            FallFromLadder.Reset();
            Utils.CountAlivePlayers(true);
            Utils.AfterMeetingTasks();

            // ⚠️ 演出中の致命的なRPC爆撃（SyncSettingsなど）を一旦スキップし、安全なタイミングへ逃がす
            /*
            if (mapId != 4)
            {
                foreach (var pc in Main.AllPlayerControls)
                {
                    pc.GetRoleClass()?.OnSpawn();
                    pc.SyncSettings();
                    pc.RpcResetAbilityCooldown();
                }
            }
            */
            Utils.NotifyRoles();

            if (HudManager.Instance != null)
            {
                HudManager.Instance.SetHudActive(true);
            }
        }

        public static void WrapUpFinalizer(NetworkedPlayerInfo exiled)
        {
            if (AmongUsClient.Instance.AmHost)
            {
                _ = new LateTask(() =>
                {
                    exiled = AntiBlackout_LastExiled;
                    AntiBlackout.SendGameData();

                    // 💡 スキップしていた追放同期RPCを、安全な遅延タスク（0.5秒後）の中で最小限復活させる
                    if (AntiBlackout.OverrideExiledPlayer && exiled != null && exiled.Object != null)
                    {
                        try { exiled.Object.RpcExile(); } catch { }
                    }
                }, 0.5f, "Restore IsDead Task");

                _ = new LateTask(() =>
                {
                    Main.AfterMeetingDeathPlayers.Do(x =>
                    {
                        var player = Utils.GetPlayerById(x.Key);
                        if (player == null) return;

                        var roleClass = CustomRoleManager.GetByPlayerId(x.Key);
                        var requireResetCam = player.GetCustomRole().GetRoleInfo()?.IsDesyncImpostor == true;
                        var state = PlayerState.GetByPlayerId(x.Key);

                        Logger.Info($"{player.GetNameWithRole()}を{x.Value}で死亡させました", "AfterMeetingDeath");
                        state.DeathReason = x.Value;
                        state.SetDead();

                        // 💡 自殺や役職変化など、本当に演出が必要なプレイヤーにのみ安全に送信
                        try { player.RpcExile(); } catch { }

                        if (x.Value == CustomDeathReason.Suicide)
                            player.SetRealKiller(player, true);
                        if (requireResetCam)
                            player.ResetPlayerCam(1f);
                        if (roleClass is Executioner executioner && executioner.TargetId == x.Key)
                            Executioner.ChangeRoleByTarget(x.Key);
                    });
                    Main.AfterMeetingDeathPlayers.Clear();

                    // 💡 スキップしていた初期化ロジックを、演出ストリームが安定したこのタイミングで安全に実行
                    try
                    {
                        foreach (var pc in Main.AllPlayerControls)
                        {
                            if (pc == null) continue;
                            pc.GetRoleClass()?.OnSpawn();
                            pc.SyncSettings();
                            pc.RpcResetAbilityCooldown();
                        }
                    }
                    catch { }

                }, 0.5f, "AfterMeetingDeathPlayers Task");
            }

            GameStates.AlreadyDied |= !Utils.IsAllAlive;
            RemoveDisableDevicesPatch.UpdateDisableDevices();

            if (SoundManager.Instance != null && DataManager.Settings?.Audio != null)
            {
                SoundManager.Instance.ChangeAmbienceVolume(DataManager.Settings.Audio.AmbienceVolume);
            }

            try
            {
                var roleInfo = PlayerControl.LocalPlayer.GetCustomRole().GetRoleInfo();
                RoleTypes role = (roleInfo?.IsDesyncImpostor == true && roleInfo.BaseRoleType.Invoke() == RoleTypes.Impostor)
                    ? RoleTypes.Crewmate
                    : (roleInfo?.BaseRoleType?.Invoke() ?? RoleTypes.Crewmate);

                if (!PlayerControl.LocalPlayer.IsAlive())
                {
                    switch (role)
                    {
                        case RoleTypes.Impostor:
                        case RoleTypes.Shapeshifter:
                        case RoleTypes.Phantom:
                        case RoleTypes.Viper:
                            role = RoleTypes.ImpostorGhost;
                            break;
                        default:
                            role = RoleTypes.CrewmateGhost;
                            break;
                    }
                }
                RoleManager.Instance.SetRole(PlayerControl.LocalPlayer, role);
            }
            catch (Exception e)
            {
                Logger.Error($"SetRole Restore Error: {e}", "Exile");
            }

            GameStates.InTask = true;
            Logger.Info("タスクフェイズ開始", "Phase");
        }
    }
}