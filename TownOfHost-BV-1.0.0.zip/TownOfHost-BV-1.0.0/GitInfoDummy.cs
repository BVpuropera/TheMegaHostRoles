namespace TownOfHost
{
    public static class ThisAssembly
    {
        public static class Git
        {
            public const string Commit = "<color=#B998C500>";
            public const string Sha = "0000000";
            public const string Branch = "<color=#B998C500>";

            // 💡 メンヘラを起こしたmain.csたちを黙らせる追加データ
            public const string BaseTag = "5.1.14";
            public const string Commits = "0";
            public const string IsDirty = "false";
            public const string Tag = "5.1.14";
        }
    }
}