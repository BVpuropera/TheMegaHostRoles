using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Crewmate
{
    public sealed class Knight : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(Knight),
                player => new Knight(player),
                CustomRoles.Knight,
                () => RoleTypes.Crewmate,
                CustomRoleTypes.Crewmate,
                2050,
                SetupOptionItem,
                "kni",
                "#00FFCC",
                true
            );

        // 💡 現在のモード状態（true: 守護モード / false: 通常投票モード）
        public bool IsGuardMode = false;

        // 💡 次のラウンドで守る対象のプレイヤーID
        public byte ProtectedPlayerId = 255;

        public Knight(PlayerControl player) : base(RoleInfo, player, () => HasTask.True)
        {
        }

        private static void SetupOptionItem() { }

        public override void Add()
        {
            IsGuardMode = false;
            ProtectedPlayerId = 255;
        }

        // 💡 会議が始まった瞬間に呼ばれるフック（名前を OnStartMeeting に修正）
        public override void OnStartMeeting()
        {
            IsGuardMode = false;
            ProtectedPlayerId = 255;
        }

        // 💡 誰かが投票した瞬間に呼ばれ、票を検知・書き換えられるフック
        public override (byte? votedForId, int? numVotes, bool doVote) ModifyVote(byte voterId, byte sourceVotedForId, bool isIntentional)
        {
            // 投票したのがこの「騎士」自身である場合のみ処理
            if (voterId == Player.PlayerId)
            {
                // 🌟 自分自身に投票した場合：モードを反転させる
                if (sourceVotedForId == Player.PlayerId)
                {
                    IsGuardMode = !IsGuardMode;

                    // モード切り替えのログ（ここにHUDメッセージ等を入れるとより親切です）
                    string modeText = IsGuardMode ? "【守護モード】" : "【通常投票モード】";
                    Logger.Info($"騎士のモード切り替え: {modeText}", "Knight");

                    // 自分への投票行動自体はカウントさせないようにキャンセルして戻す
                    return (null, null, false);
                }

                // 🌟 守護モード中に、自分以外の誰かに投票した場合：その人を守護対象にロック
                if (IsGuardMode && sourceVotedForId != 255 && sourceVotedForId != 254) // 255:未投票, 254:スキップ
                {
                    ProtectedPlayerId = sourceVotedForId;
                    Logger.Info($"騎士は次のラウンドでプレイヤーID {ProtectedPlayerId} を守ります。", "Knight");

                    // 守る対象への投票自体はそのまま通す（必要なら変更可能）
                    return (sourceVotedForId, null, true);
                }
            }

            // 騎士以外の投票、または通常モード時の通常投票はバニラ処理のまま通す
            return (null, null, true);
        }

        // 💡 会議終了時（タスクターンが始まる直前）に呼ばれるフック
        public override void AfterMeetingTasks()
        {
            // もし守護モードのまま誰も選ばずに会議が終わったら守護リセット
            if (!IsGuardMode || ProtectedPlayerId == 255)
            {
                ProtectedPlayerId = 255;
            }
        }

        // 💡 キル発生時に割り込んで守護するロジック
        public void OnCheckMurderAsKiller(MurderInfo info)
        {
            (var killer, var target) = info.AttemptTuple;

            if (target != null && target.PlayerId == ProtectedPlayerId)
            {
                info.DoKill = false; // キルを完全に無効化
                Logger.Info($"[Knight] {target.name} をインポスターのキルから守り抜いた！", "Knight");

                // 1回守ったら守護解除
                ProtectedPlayerId = 255;
            }
        }
    }
}