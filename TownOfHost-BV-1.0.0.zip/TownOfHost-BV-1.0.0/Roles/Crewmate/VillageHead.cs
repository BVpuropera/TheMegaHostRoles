/*
using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Crewmate;

public sealed class VillageHead : RoleBase, IKiller
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(VillageHead),
            player => new VillageHead(player),
            CustomRoles.VillageHead,
            () => RoleTypes.Impostor,
            CustomRoleTypes.Crewmate,
            9273,
            SetUpOptionItem,
            "VillageHead",
            "#f8cd46",
            isDesyncImpostor: true,   // 抽選プールに出現させる
            introSound: () => GetIntroSound(RoleTypes.Crewmate)
        );

    public VillageHead(PlayerControl player)
        : base(RoleInfo, player)
    {
        _ = new LateTask(() =>
        {
            if (Player == null || !Player.IsAlive()) return;

            if (AmongUsClient.Instance.AmHost)
            {
                Player.SyncSettings();
            }
        }, 8f, "VillageHeadStartInit");
    }

    static OptionItem OptionKillCooldown;

    enum OptionName
    {
        VillageHeadKillCooldown,
    }

    static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.VillageHeadKillCooldown, new(10f, 60f, 2.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);
    }

    // 🌟 IKillerインターフェースの実装
    // 【修正】生きていて、かつバニラ役職がインポスター（サイドキック化された後）ならキルボタンを使えるようにする
    public bool CanUseKillButton() => Player.IsAlive() && Player.Data.RoleType == RoleTypes.Impostor;
    public bool CanUseSabotageButton() => false;
    public bool CanUseImpostorVentButton() => false;

    // クルー陣営なのでインポスターのキル数カウントからは除外
    bool IKiller.IsKiller => false;

    // クールダウンの計算（バニラ側にそのまま値を返す）
    public float CalculateKillCooldown()
    {
        return OptionKillCooldown.GetFloat();
    }

    // 🌟 【超重要】キルボタンが押された瞬間にホスト側でバニラキルを乗っ取る処理
    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        // 自分がキルを実行しようとした、かつ自殺イベントではない場合
        if (Is(info.AttemptKiller) && !info.IsSuicide)
        {
            (var killer, var target) = info.AttemptTuple;

            // ➔ 1. まずバニラの「相手を死亡させて死体を残すキル」を完全にキャンセル！
            info.DoKill = false;

            if (target == null || target.Data.IsDead) return;

            // ➔ 2. キャンセルに成功したら、裏で村長本来の能力を安全に実行する
            if (AmongUsClient.Instance.AmHost)
            {
                ExecuteVillageHeadAbility(target);
            }
        }
    }

    // 🌟 Pko環境に最適化した能力処理メソッド（重複を排除して1つに統合）
    private void ExecuteVillageHeadAbility(PlayerControl target)
    {
        Logger.Info($"[VillageHead] 能力を使用しました。対象: {target.GetNameWithRole()}", "VillageHead");

        // クルー陣営を検知した場合（成功ルート）
        if (!target.GetCustomRole().IsImpostor() && !target.GetCustomRole().IsNeutral())
        {
            Logger.Info($"[VillageHead] クルーを検知。サイドキック化処理を開始します。", "VillageHead");

            // 1. 対象のタスクの全消去と完了
            foreach (var task in target.Data.Tasks.ToArray())
            {
                target.RpcCompleteTask(task.Id);
            }
            var targetState = TownOfHost.PlayerState.GetByPlayerId(target.PlayerId);
            targetState?.GetTaskState()?.Update(target);

            // 2. 相互保護処理
            Player.RpcProtectedMurderPlayer(target);
            target.RpcProtectedMurderPlayer(Player);
            target.RpcProtectedMurderPlayer(target);

            // 3. 役職の書き換え（Pkoの仕様に合わせて log: null を指定）
            // 対象（相手）のカスタム役職は「VillageHead」のまま、バニラ役職をインポスターに変える
            target.RpcSetCustomRole(CustomRoles.Sheriff);
            target.RpcSetRole(RoleTypes.Impostor);

            // 自分（元村長）は通常のクルーメイトに降格させる
            Player.RpcSetCustomRole(CustomRoles.VillageHead);
            Player.RpcSetRole(RoleTypes.Crewmate);

            // 4. キルクールダウン強制初期化（新村長用）
            target.ResetKillCooldown();
            target.SetKillCooldown();
            target.RpcResetAbilityCooldown();

            // 5. 全プレイヤーの画面・設定同期（UtilsOptionの代わりに直接リフレッシュ）
            foreach (var p in PlayerControl.AllPlayerControls)
            {
                p.MarkDirtySettings(); // プレイヤー個別の設定更新フラグ
                p.SyncSettings();      // 同期
            }

           //UtilsNotifyRoles.NotifyRoles();
        }
        // 非クルー（インポスター・第三陣営）だった場合（失敗ルート：自殺）
        else
        {
            Logger.Info($"[VillageHead] 非クルーを検知。村長は自殺します。", "VillageHead");
            var myState = TownOfHost.PlayerState.GetByPlayerId(Player.PlayerId);
            if (myState != null)
            {
                myState.DeathReason = CustomDeathReason.Suicide;
            }
            Player.RpcMurderPlayer(Player);
        }
    }
}
*/