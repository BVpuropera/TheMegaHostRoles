using System;
using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;

namespace TownOfHost.Roles.Crewmate
{
    public class Neet : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(Neet),
                player => new Neet(player),
                CustomRoles.Neet,
                () => RoleTypes.Crewmate, // ベースはクルーメイト
                CustomRoleTypes.Crewmate,
                888888, // 固有の役職ID
                null,
                "neet",
                "#808080",
                false
            );

        // 💡 base() の第3引数に「() => HasTask.False」をぶち込む！
        public Neet(PlayerControl player) : base(RoleInfo, player, () => HasTask.False, null)
        {
            // ➔ 前にあったタスクを強制完了する foreach などの泥臭い処理は一切不要に！
            // これだけでシステム的に「このプレイヤーはタスクを持ちません」と認識されます。
        }

        public override void Add()
        {
        }
    }
}