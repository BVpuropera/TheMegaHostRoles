using System.Linq;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Crewmate;

public class Technician : RoleBase, IKiller
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Technician),
            player => new Technician(player),
            CustomRoles.Technician,
            () => RoleTypes.Impostor,
            CustomRoleTypes.Crewmate,
            86040,
            null,
            "tech",
            "#00FFFF",
            isDesyncImpostor: true,
            introSound: () => GetIntroSound(RoleTypes.Engineer)
        );
    public Technician(PlayerControl player) : base(RoleInfo, player, () => HasTask.False)
    {
    }
    private bool IsAnySabotageActive()
    {
        return Utils.IsActive(SystemTypes.Reactor)
            || Utils.IsActive(SystemTypes.Electrical)
            || Utils.IsActive(SystemTypes.Laboratory)
            || Utils.IsActive(SystemTypes.Comms)
            || Utils.IsActive(SystemTypes.LifeSupp)
            || Utils.IsActive(SystemTypes.HeliSabotage);
    }
    public bool CanUseVentButton()
    {
        if (Player == null || !Player.IsAlive()) return false;
        return IsAnySabotageActive() || Player.inVent;
    }
    public bool CanUseImpostorVentButton()
    {
        if (Player == null || !Player.IsAlive()) return false;
        return IsAnySabotageActive() || Player.inVent;
    }
    public bool CanUseKillButton() => false;
    public float CalculateKillCooldown() => 300f;
    public bool CanUseSabotageButton() => false;
    public bool CanUseImpostorSabotageButton() => false;
    bool IKiller.IsKiller => false;
    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        if (Is(info.AttemptKiller))
        {
            info.DoKill = false;
        }
    }
}