using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;

namespace TownOfHost.Roles.Crewmate
{
    public class Doc : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(Doc),
                player => new Doc(player),
                CustomRoles.Doc,
                () => RoleTypes.Scientist,
                CustomRoleTypes.Crewmate,
                757575,
                null,
                "do",
                "#00FF00",
                false
            );

        public Doc(PlayerControl player) : base(RoleInfo, player)
        {
            TaskCompletedBatteryCharge = OptionTaskCompletedBatteryCharge.GetFloat();
        }

        private static OptionItem OptionTaskCompletedBatteryCharge;

        enum OptionName
        {
            DoctorTaskCompletedBatteryCharge
        }

        private float TaskCompletedBatteryCharge;

        public static void SetupOptionItem()
        {
            OptionTaskCompletedBatteryCharge = FloatOptionItem.Create(
                RoleInfo,
                10,
                OptionName.DoctorTaskCompletedBatteryCharge,
                new(0f, 10f, 1f),
                5f,
                false
            ).SetValueFormat(OptionFormat.Seconds);
        }

        // 💡 メソッド名を修正！ゲーム開始時にこの役職の設定（キャッシュ）を上書きする
        public override void ApplyGameOptions(IGameOptions opt)
        {
            // クールダウン（回復時間）を 1f（ほぼ0秒）に設定
            AURoleOptions.ScientistCooldown = 0.016f;

            // バッテリー持続時間を 255秒（実質無限）に設定
            AURoleOptions.ScientistBatteryCharge = 255f;
        }
    }
}