using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;
using HarmonyLib;

namespace TownOfHost.Roles.Crewmate;

public sealed class Stuntman : RoleBase
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Stuntman),
            player => new Stuntman(player),
            CustomRoles.Stuntman,
            () => RoleTypes.Crewmate,
            CustomRoleTypes.Crewmate,
            1239,
            SetUpOptionItem,
            "Stuntman",
            "#00ff00",
            introSound: () => GetIntroSound(RoleTypes.Scientist)
        );

    public static Dictionary<byte, int> RemainingLives = new();

    public Stuntman(PlayerControl player) : base(RoleInfo, player)
    {
        if (AmongUsClient.Instance.AmHost && player != null)
        {
            RemainingLives[player.PlayerId] = 2;
        }
    }

    static void SetUpOptionItem() { }
}

// 🌟 守護天使の保護IDを偽装してバニラのバリアを発動させるパッチ
[HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.MurderPlayer))]
public static class StuntmanShieldPatch
{
    public static bool Prefix(PlayerControl __instance, PlayerControl target)
    {
        if (target == null || !AmongUsClient.Instance.AmHost) return true;

        if (target.GetCustomRole() == CustomRoles.Stuntman)
        {
            byte targetId = target.PlayerId;

            if (Stuntman.RemainingLives.ContainsKey(targetId))
            {
                // 1回目のキルを検知
                if (Stuntman.RemainingLives[targetId] == 2)
                {
                    Stuntman.RemainingLives[targetId] = 1; // ライフを消費

                    Logger.Info($"[Stuntman] {target.name} が狙われました。守護天使IDを偽装してキルを無効化します。", "Stuntman");

                    // 🌟 【超重要トリック】一時的に守護天使に守られている状態（ID: 0）にする
                    target.protectedByGuardianId = 0;

                    // キル処理が走ってバリアで弾かれた直後（0.1秒後）に、IDを-1（未保護）に戻す
                    _ = new LateTask(() =>
                    {
                        if (target != null)
                        {
                            target.protectedByGuardianId = -1;
                        }
                    }, 0.1f, "StuntmanShieldReset");

                    // ➔ `return true;` にしてキル処理をそのままバニラに流す！
                    // これにより、バニラシステムが「バリアがあるからキル無効」と正常に同期処理してくれます。
                    return true;
                }

                // 2回目のキルは通常通り死亡
                if (Stuntman.RemainingLives[targetId] == 1)
                {
                    Logger.Info($"[Stuntman] {target.name} のライフがありません。通常通りキルを通します。", "Stuntman");
                    return true;
                }
            }
        }
        return true;
    }
}