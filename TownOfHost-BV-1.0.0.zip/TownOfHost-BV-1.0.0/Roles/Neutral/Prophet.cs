using System;
using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Neutral;

public sealed class Prophet : RoleBase
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Prophet),
            player => new Prophet(player),
            CustomRoles.Prophet, // ※CustomRolesへの追加が必要です
            () => RoleTypes.Shapeshifter, // 判定はシェイプシフター
            CustomRoleTypes.Neutral, // 第三陣営
            9284, // 固有のID（重複しないように適宜調整してください）
            SetUpOptionItem,
            "Prophet",
            "#4A90E2", // 予言者っぽい青系のカラー（お好みで変更してください）
            isDesyncImpostor: true
        );

    // 予言者の内部状態
    public int CurrentPoints { get; private set; } = 10; // 初期ポイントは10
    public byte PredictedPlayerId { get; private set; } = 255; // 255は「誰も指定していない」状態

    public Prophet(PlayerControl player) : base(RoleInfo, player)
    {
        // 最初のターン開始時の初期化
        CurrentPoints = 10;
        PredictedPlayerId = 255;
    }

    static OptionItem OptionWinPoints;

    enum OptionName
    {
        ProphetWinPoints,
    }

    static void SetUpOptionItem()
    {
        // 乗っ取り勝利に必要なポイント（デフォルト30）
        OptionWinPoints = FloatOptionItem.Create(RoleInfo, 0, OptionName.ProphetWinPoints, new(20f, 100f, 5f), 30f, false)
            .SetValueFormat(OptionFormat.None);
    }
    // キルはできない
    public bool CanUseKillButton() => false;

    // ① 【変身ボタンを押した瞬間】変身そのものはキャンセルする
    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        if (Player.Data.IsDead || Player.inVent) return false;

        // 変身アニメーションを無効化
        animate = false;

        if (target != null)
        {
            // 予言の対象を選択（何度でも再指定可能）
            PredictedPlayerId = target.PlayerId;
            Logger.Info($"[Prophet] {Player.Data.PlayerName} が {target.Data.PlayerName} の死を予言しました。", "Prophet");
        }

        // falseを返すことで、バニラの変身処理（見た目が変わる処理）を完全にブロックする
        return false;
    }

    // ターン終了時（会議開始時など）に予言の答え合わせを行うメソッド
    // ※ ターン中に誰が死んだかをチェックするシステムフック（OnMeetingStart等）からこれを呼び出します
    public void CheckPrediction(List<byte> deadPlayerIdsInThisTurn)
    {
        if (Player.Data.IsDead) return;

        int targetWinPoints = (int)OptionWinPoints.GetFloat();

        // 1. 誰も指定していない場合（誰も死なないという予言）
        if (PredictedPlayerId == 255)
        {
            if (deadPlayerIdsInThisTurn.Count == 0)
            {
                CurrentPoints += 10;
                Logger.Info($"[Prophet] 予言的中：誰も死にませんでした。(現在のpt: {CurrentPoints})", "Prophet");
            }
            else
            {
                CurrentPoints -= 10;
                Logger.Info($"[Prophet] 予言外れ：死者が出ました。(現在のpt: {CurrentPoints})", "Prophet");
            }
        }
        // 2. 特定のプレイヤーを予言していた場合
        else
        {
            if (deadPlayerIdsInThisTurn.Contains(PredictedPlayerId))
            {
                CurrentPoints += 10;
                Logger.Info($"[Prophet] 予言成功：対象が死亡しました。(現在のpt: {CurrentPoints})", "Prophet");
            }
            else
            {
                CurrentPoints -= 10;
                Logger.Info($"[Prophet] 予言失敗：対象が生還しました。(現在のpt: {CurrentPoints})", "Prophet");
            }
        }

        // 次のターンのために予言をリセット（誰も指定していない状態へ）
        PredictedPlayerId = 255;

        // 💀 0pt以下になったら自殺する
        if (CurrentPoints <= 0)
        {
            Logger.Info($"[Prophet] ポイントが0以下になったため自殺します。", "Prophet");
            Player.Exiled(); // またはホスト側からキルRPCを飛ばす処理
            return;
        }

        // 🏆 設定ポイントを超えたら単独勝利（乗っ取り勝利）
        if (CurrentPoints >= targetWinPoints)
        {
            Logger.Info($"[Prophet] 目標ポイント達成！単独勝利します。", "Prophet");
            // TOHの勝利リザルト呼び出し処理（ExiledEndGame等）をここに差し込みます
        }
    }
}