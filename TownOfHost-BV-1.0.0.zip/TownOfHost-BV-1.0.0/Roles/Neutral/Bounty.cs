using System.Collections.Generic;
using UnityEngine;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using static TownOfHost.Translator;
using Hazel;
using HarmonyLib;
using System;

namespace TownOfHost.Roles.Neutral
{
    public sealed class Bounty : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(Bounty),
                player => new Bounty(player),
                CustomRoles.Bounty,
                () => RoleTypes.Shapeshifter,
                CustomRoleTypes.Neutral,
                91892,
                SetupOptionItem,
                "bounty",
                "#ff6633",
                true,
                introSound: () => GetIntroSound(RoleTypes.Crewmate)
            );

        public static PlayerControl bountyPlayer { get; private set; }

        public Bounty(PlayerControl player) : base(RoleInfo, player, () => HasTask.False)
        {
        }

        private static void SetupOptionItem()
        {
        }

        public override void Add()
        {
            bountyPlayer = Player;
        }

        public override void OnDestroy()
        {
            if (bountyPlayer == Player)
            {
                bountyPlayer = null;
            }
        }

        public override void ApplyGameOptions(IGameOptions opt)
        {
        }

        public override void OnShapeshift(PlayerControl target)
        {
            // 他のロールでも使われている一般的なホストかつゲーム中（ShipStatusが存在する）の判定
            if (!AmongUsClient.Instance.AmHost || ShipStatus.Instance == null) return;
            if (Player.Data.IsDead || Player.inVent) return;

            ExecuteSelfDestruct();
        }

        private void ExecuteSelfDestruct()
        {
            if (Player == null || !Player.IsAlive()) return;

            Logger.Info($"{Player.GetNameWithRole()} が変身ボタンを押したため自爆します！", "Bounty");

            if (AmongUsClient.Instance.AmHost)
            {
                MyState.DeathReason = CustomDeathReason.Suicide;
                Player.RpcMurderPlayer(Player);
            }
        }

        public static bool CheckWin()
        {
            if (!AmongUsClient.Instance.AmHost) return false;

            if (bountyPlayer != null && bountyPlayer.IsAlive())
            {
                Logger.Info("ゲーム終了時にバウンティが生存していたため、勝利を乗っ取ります！", "BountyWin");
                Win();
                return true;
            }

            return false;
        }

        private static void Win()
        {
            CustomWinnerHolder.ShiftWinnerAndSetWinner(CustomWinner.Bounty);
            CustomWinnerHolder.WinnerIds.Add(bountyPlayer.PlayerId);
        }

        public static void ResetStatus()
        {
            bountyPlayer = null;
            BountyUpdatePatch.ClearTimers();
            Logger.Info("Bountyの状態をリセットしました。", "Bounty");
        }
    }

    [HarmonyPatch(typeof(PlayerControl), nameof(PlayerControl.FixedUpdate))]
    public static class BountyUpdatePatch
    {
        private static readonly Dictionary<byte, float> proximityTimers = new();

        public static void ClearTimers()
        {
            proximityTimers.Clear();
        }

        public static void Postfix(PlayerControl __instance)
        {
            if (!AmongUsClient.Instance.AmHost) return;

            // ShipStatus.Instance が存在すること（＝ゲームが始まっていること）を安全に確認
            if (ShipStatus.Instance == null || __instance == null || !__instance.IsAlive())
            {
                return;
            }

            if (__instance.GetCustomRole() == CustomRoles.Bounty)
            {
                byte playerId = __instance.PlayerId;

                if (!proximityTimers.ContainsKey(playerId))
                {
                    proximityTimers[playerId] = 0f;
                }

                bool isNearAnyone = false;
                foreach (var pc in Main.AllPlayerControls)
                {
                    if (pc == null || pc.PlayerId == playerId || !pc.IsAlive()) continue;

                    float distance = Vector2.Distance(__instance.transform.position, pc.transform.position);
                    if (distance < 1.8f)
                    {
                        isNearAnyone = true;
                        break;
                    }
                }

                if (isNearAnyone)
                {
                    proximityTimers[playerId] += Time.deltaTime;
                    if (proximityTimers[playerId] >= 5.0f)
                    {
                        Logger.Info($"{__instance.GetNameWithRole()} が人混みを避けられず自爆しました", "Bounty");

                        var state = PlayerState.GetByPlayerId(playerId);
                        if (state != null) state.DeathReason = CustomDeathReason.Suicide;

                        __instance.RpcMurderPlayer(__instance);
                        proximityTimers[playerId] = 0f;
                    }
                }
                else
                {
                    proximityTimers[playerId] = 0f;
                }
            }
        }
    }

    [HarmonyPatch(typeof(AmongUsClient), nameof(AmongUsClient.ExitGame))]
    public static class BountyLeavePatch
    {
        public static void Postfix()
        {
            Bounty.ResetStatus();
        }
    }
}