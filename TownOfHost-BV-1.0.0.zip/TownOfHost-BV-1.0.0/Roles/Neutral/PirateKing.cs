using System.Collections.Generic;
using UnityEngine;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using static TownOfHost.Translator;
using Hazel;

namespace TownOfHost.Roles.Neutral
{
    public sealed class PirateKing : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(PirateKing),
                player => new PirateKing(player),
                CustomRoles.PirateKing,
                () => RoleTypes.Crewmate,
                CustomRoleTypes.Neutral,
                810,
                SetupOptionItem,
                "pk",
                "#FFD700",
                true
            );

        private static Options.OverrideTasksData Tasks;

        public PirateKing(PlayerControl player) : base(RoleInfo, player, () => HasTask.ForRecompute)
        {
        }

        private static void SetupOptionItem()
        {
            Tasks = Options.OverrideTasksData.Create(RoleInfo, 20);
        }

        public override void OnFixedUpdate(PlayerControl player)
        {
            if (!AmongUsClient.Instance.AmHost) return;
        }

        // 💡 ここ！イベントリスナーを使わず、TOHの追放時の処理に割り込む方法です
        public override void OnExileWrapUp(NetworkedPlayerInfo exiled, ref bool DecidedWinner)
        {
            // もし追放されたのが自分自身なら
            if (exiled.PlayerId == Player.PlayerId)
            {
                // ここでタスク完了チェック
                if (Player.AllTasksCompleted())
                {
                    Win();
                    DecidedWinner = true; // TOHの勝利判定を乗っ取る
                }
                else
                {
                    // 未完了なら自爆（追放＋キル）
                    MyState.DeathReason = CustomDeathReason.Suicide;
                    Player.RpcMurderPlayer(Player);
                    Logger.SendInGame($"{Player.GetNameWithRole()} はタスク未完了で追放され、爆発四散した！");
                }
            }
        }

        private void Win()
        {
            foreach (var pc in Main.AllAlivePlayerControls)
            {
                if (pc.PlayerId != Player.PlayerId)
                {
                    pc.SetRealKiller(Player);
                    pc.RpcMurderPlayer(pc);
                    var state = PlayerState.GetByPlayerId(pc.PlayerId);
                    state.DeathReason = CustomDeathReason.boom;
                    state.SetDead();
                }
                else
                {
                    RPC.PlaySoundRPC(pc.PlayerId, Sounds.KillSound);
                }
            }
            CustomWinnerHolder.ShiftWinnerAndSetWinner(CustomWinner.PirateKing);
            CustomWinnerHolder.WinnerIds.Add(Player.PlayerId);
        }

        public override string GetLowerText(PlayerControl seer, PlayerControl seen = null, bool isForMeeting = false, bool isForHud = false)
        {
            if (isForMeeting || !Is(seer)) return "";

            return Player.AllTasksCompleted()
                ? Utils.ColorString(RoleInfo.RoleColor, "タスク完了、追放されて勝利せよ！")
                : Utils.ColorString(new Color32(255, 51, 51, 255), "警告：タスク未完了で追放されると勝利できません");
        }
    }
}