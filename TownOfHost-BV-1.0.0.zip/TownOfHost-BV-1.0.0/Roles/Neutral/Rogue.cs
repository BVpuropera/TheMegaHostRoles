using System;
using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Neutral;

public sealed class Rogue : RoleBase, IKiller
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Rogue),
            player => new Rogue(player),
            CustomRoles.Rogue,
            () => RoleTypes.Shapeshifter,
            CustomRoleTypes.Neutral,
            0283,
            SetUpOptionItem,
            "Rogue",
            "#B998C5",
            isDesyncImpostor: true
        );

    public CustomRoles StolenRole { get; private set; } = CustomRoles.Rogue;

    // 🌟 奪った役職のインスタンスをここに保管する
    private RoleBase _stolenRoleInstance = null;

    // 最初から「キル能力持ち（ボタン持ち）」としてバニラに認識させる（重複解消済み）
    bool IKiller.IsKiller => true;

    public Rogue(PlayerControl player) : base(RoleInfo, player)
    {
        StolenRole = CustomRoles.Rogue;

        // スポーン直後にホストからクライアントへ役職とボタン状態を強制同期する
        _ = new LateTask(() =>
        {
            if (Player == null || !Player.IsAlive()) return;
            if (AmongUsClient.Instance.AmHost)
            {
                // 役職と設定を強制リフレッシュして INVALID を剥がす
                //Utils.RpcSetCustomRole(Player, CustomRoles.Rogue);
                Player.ResetKillCooldown();
                Utils.SyncAllSettings();
            }
        }, 0.5f, "RogueButtonInit"); // 少し早めに実行
    }

    static OptionItem OptionKillCooldown;
    static OptionItem OptionShiftCooldown;

    enum OptionName
    {
        RogueKillCooldown,
        RogueShiftCooldown,
    }

    static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.RogueKillCooldown, new(10f, 60f, 2.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);
        OptionShiftCooldown = FloatOptionItem.Create(RoleInfo, 11, OptionName.RogueShiftCooldown, new(10f, 60f, 2.5f), 20f, false)
            .SetValueFormat(OptionFormat.Seconds);
    }

    public bool CanUseKillButton() => Player.IsAlive();
    public bool CanUseSabotageButton() => false;
    public bool CanUseImpostorVentButton() => false;

    public float CalculateKillCooldown() => OptionKillCooldown.GetFloat();

    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        if (Is(info.AttemptKiller) && !info.IsSuicide)
        {
            (_, var target) = info.AttemptTuple;
            if (target == null) return;

            var targetRole = target.GetCustomRole();
            StealRoleAbility(targetRole);
        }
    }

    // 🌟 能力強奪＆ネームプレート強制書き換えロジック
    private void StealRoleAbility(CustomRoles newRole)
    {
        StolenRole = newRole;
        Logger.Info($"[Rogue] {Player.Data.PlayerName} が役職 {newRole} の能力を奪いました。", "Rogue");

        // 💡 1. 共有してもらった拡張メソッドを用いて、相手の役職のインスタンスを動的生成
        try
        {
            var targetRoleInfo = newRole.GetRoleInfo(); // 拡張メソッドを直接叩く
            if (targetRoleInfo != null)
            {
                _stolenRoleInstance = targetRoleInfo.CreateInstance(Player);
                _stolenRoleInstance?.Add();
                Logger.Info($"[Rogue] {newRole} のインスタンスを内部生成しました。", "Rogue");
            }
        }
        catch (Exception ex)
        {
            Logger.Error($"[Rogue] インスタンス生成に失敗: {ex.Message}", "Rogue");
        }

        // 💡 2. 名前を [役職名] 付きにする処理
        string targetRoleName = newRole.ToString();
        string newName = $"{Player.Data.PlayerName} [<color=#B998C5>{targetRoleName}</color>]";

        Player.Data.PlayerName = newName;
        Player.RpcSetName(newName);

        foreach (var p in PlayerControl.AllPlayerControls)
        {
            p.MarkDirtySettings();
            p.SyncSettings();
        }
    }

    // ① 【変身ボタンを押した瞬間】の処理を丸投げ
    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        if (Player.Data.IsDead || Player.inVent) return false;

        // 内部インスタンスが存在すれば、そちらの処理を最優先で実行する
        if (_stolenRoleInstance != null)
        {
            Logger.Info($"[Rogue] 奪った役職 の OnCheckShapeshift を身代わり実行します。", "Rogue");
            return _stolenRoleInstance.OnCheckShapeshift(target, ref animate);
        }

        return true;
    }

    // ② 【変身先を決定した瞬間】の処理を丸投げ
    public void OnShapeshiftTargetSelected(PlayerControl target)
    {
        if (target == null || !Player.IsAlive()) return;

        if (_stolenRoleInstance != null)
        {
            Logger.Info($"[Rogue] 奪った役職 のターゲット選択処理を走らせます。", "Rogue");
        }
    }
}