using System.Linq;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Neutral;

// 💡 IKiller, IKillFlashSeeable, IDeathReasonSeeable をすべて継承させます
public sealed class MadSaboteur : RoleBase, IKiller, IKillFlashSeeable, IDeathReasonSeeable
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(MadSaboteur),
            player => new MadSaboteur(player),
            CustomRoles.MadSabotarger,
            () => RoleTypes.Impostor,
            CustomRoleTypes.Madmate,
            7112,
            null,
            "ms",
            "#FF0000",
            isDesyncImpostor: true, // 💡 Accompliceの実績を信じて true に固定！
            introSound: () => GetIntroSound(RoleTypes.Impostor)
        );

    public MadSaboteur(PlayerControl player) : base(RoleInfo, player, () => HasTask.False)
    {
        // 💡 最初の数秒間でボタンがバグるのを防ぐため、初期タイマーと同期を明示的に処理
        _ = new LateTask(() =>
        {
            if (Player == null || !Player.IsAlive()) return;
            Player.killTimer = 300f; // キルはできないのでクールダウンは最大値にしておく

            if (AmongUsClient.Instance.AmHost)
            {
                Player.SyncSettings();
            }
        }, 8f, "MadSaboteurStartInit");
    }

    // 💡 設定値からの視界制御（Null参照対策付き）
    public bool? CheckKillFlash(MurderInfo info) => Options.MadmateCanSeeKillFlash?.GetBool() ?? false;
    public bool? CheckSeeDeathReason(PlayerControl seen) => Options.MadmateCanSeeDeathReason?.GetBool() ?? false;

    // 💡 IKillerの実装（これがボタンの命です）
    public float CalculateKillCooldown() => 300f;
    public bool CanUseSabotageButton() => true;
    public bool CanUseImpostorSabotageButton() => true;
    public bool CanUseImpostorVentButton() => true;
    public bool CanUseVentButton() => true;
    public bool CanUseImpostorKillButton() => false;
    public bool CanUseKillButton() => false;

    // 💡 IKillerとしてのカウント除外（狂人なのでインポスター数には数えない）
    bool IKiller.IsKiller => false;

    // 💡 ホスト側のキル処理が走った時の安全弁（念のため）
    public void OnCheckMurderAsKiller(MurderInfo info)
    {
        if (Is(info.AttemptKiller))
        {
            info.DoKill = false; // 万が一ボタンが押せてもキルを強制キャンセル
        }
    }

    public override void ApplyGameOptions(IGameOptions opt)
    {
        opt.SetVision(false);
    }
}