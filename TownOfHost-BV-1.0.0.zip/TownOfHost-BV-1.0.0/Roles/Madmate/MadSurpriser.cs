using System;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;

namespace TownOfHost.Roles.Madmate; // マッド系陣営

public sealed class MadSurpriser : RoleBase
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(MadSurpriser),
            player => new MadSurpriser(player),
            CustomRoles.MadSurpriser, // ※Enumへの追加が必要です
            () => RoleTypes.Engineer, // 判定はクルーメイト
            CustomRoleTypes.Madmate,   // マッドメイト（インポスター陣営・カウントはクルー）
            3114516,
            null,
            "MadSurpriser",
            "#FF0000", // マッドサプライザーのカラー
            isDesyncImpostor: false
        );

    public MadSurpriser(PlayerControl player) : base(RoleInfo, player) { }
    public override void ApplyGameOptions(IGameOptions opt)
    {
        AURoleOptions.EngineerCooldown = 0;
        AURoleOptions.EngineerInVentMaxTime = 0;
    }
}