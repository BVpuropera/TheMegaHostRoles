namespace TownOfHost.Roles.Core.Interfaces;

public interface IStealthTimeLimit
{
    // オプションから取得した現在のステルス時間を返すメソッド
    public float GetStealthDuration();
}