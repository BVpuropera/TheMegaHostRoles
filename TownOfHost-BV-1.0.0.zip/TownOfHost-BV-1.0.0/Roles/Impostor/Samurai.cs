using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;
using System.Collections.Generic;
using System.Linq;

namespace TownOfHost.Roles.Impostor
{
    public class Samurai : RoleBase, IImpostor
    {
        public enum SamuraiState
        {
            Ready = 0,
            UsedReady = 1,
            Used = 2
        }

        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(Samurai),
                player => new Samurai(player),
                CustomRoles.Samurai,
                () => RoleTypes.Shapeshifter,
                CustomRoleTypes.Impostor,
                8103,
                null,
                "samurai",
                "#FF0000",
                false,
            introSound: () => GetIntroSound(RoleTypes.Impostor)
            );

        public SamuraiState State = SamuraiState.Ready;
        public float SamuraiRadius = 3.0f;

        public Samurai(PlayerControl player) : base(RoleInfo, player)
        {
        }

        public override void Add()
        {
            State = SamuraiState.Ready;
        }

        public override void ApplyGameOptions(IGameOptions opt)
        {
            // 💡 あなたのアイデア通り、変身時間を「1.0秒」に固定！
            // TOHのシステムが部屋の全プレイヤーにこの設定を自動で同期してくれます。
            AURoleOptions.ShapeshifterDuration =1f;
        }

        public override void OnShapeshift(PlayerControl target)
        {
            // 変身した瞬間は true、1秒後に自動解除された瞬間は false になります
            var shapeshifting = !Is(target);

            if (shapeshifting)
            {
                // 1️⃣ 変身した瞬間（1回目：スマホ側がボタンを押したとき）
                if (State == SamuraiState.Ready)
                {
                    State = SamuraiState.UsedReady;
                }
                return; // 変身した瞬間はまだ斬らずに、1秒後の自動解除を待ちます
            }

            // 2️⃣ 1秒経って自動的に元の姿に戻った瞬間（2回目）
            if (State == SamuraiState.UsedReady)
            {
                Logger.Info("抜刀一閃！", "Samurai");

                if (AmongUsClient.Instance.AmHost)
                {
                    Vector2 myPos = this.Player.transform.position;

                    foreach (var killTarget in Main.AllAlivePlayerControls)
                    {
                        if (killTarget == this.Player) continue;

                        var dis = Vector2.Distance(myPos, killTarget.transform.position);
                        if (dis <= SamuraiRadius)
                        {
                            PlayerState.GetByPlayerId(killTarget.PlayerId).DeathReason = CustomDeathReason.slash;
                            killTarget.SetRealKiller(this.Player);
                            killTarget.RpcMurderPlayer(killTarget);
                        }
                    }
                    this.Player.MarkDirtySettings();
                }

                // 使い終わったので使用済みにする
                State = SamuraiState.Used;
                Utils.NotifyRoles();
            }
        }
    }
}