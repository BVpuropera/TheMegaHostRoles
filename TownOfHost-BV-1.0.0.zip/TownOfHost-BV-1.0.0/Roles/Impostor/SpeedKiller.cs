using System.Collections;
using System.Collections.Generic;
using AmongUs.GameOptions;
using BepInEx.Unity.IL2CPP.Utils;
using TownOfHost.Roles.Core;
using UnityEngine;

namespace TownOfHost.Roles.Impostor
{
    public sealed class SpeedKiller : RoleBase
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(SpeedKiller),
                player => new SpeedKiller(player),
                CustomRoles.SpeedKiller,
                () => RoleTypes.Impostor,
                CustomRoleTypes.Impostor,
                721,
                null,
                "sk",
                "#FF0000"
            );

        private int _lastKillCount = 0;
        private bool _isBoosting = false;
        private const float SpeedMultiplier = 2.0f;

        public SpeedKiller(PlayerControl player) : base(RoleInfo, player)
        {
            if (Player != null)
            {
                // ゲーム開始時のキル数を安全に取得して記録
                _lastKillCount = MyState.GetKillCount(true);
            }
        }

        // 💡 Updateの代わりにTOH仕様のOnFixedUpdateを使う！
        public override void OnFixedUpdate(PlayerControl player)
        {
            if (Player == null || _isBoosting) return;

            // 💡 MyState.GetKillCountを使って安全にキル数を監視
            int currentKills = MyState.GetKillCount(true);
            if (currentKills > _lastKillCount)
            {
                _lastKillCount = currentKills;

                Player.StartCoroutine(SpeedBoostCoroutine());
            }
        }

        public void OnCheckMurderAsKiller(MurderInfo info)
        {
            if (_isBoosting) return;
            _lastKillCount = MyState.GetKillCount(true);
            Player.StartCoroutine(SpeedBoostCoroutine());
        }

        private IEnumerator SpeedBoostCoroutine()
        {
            _isBoosting = true;

            // 🚀 スピードブースターの仕様を完全再現
            Main.AllPlayerSpeed[Player.PlayerId] *= SpeedMultiplier;
            Player.MarkDirtySettings(); // クライアントへ送信

            // 10秒間待機
            yield return new WaitForSeconds(10f);

            // 🛑 速度を元に戻す
            Main.AllPlayerSpeed[Player.PlayerId] /= SpeedMultiplier;
            Player.MarkDirtySettings(); // クライアントへ送信

            _isBoosting = false;
        }

        public override void OnDestroy()
        {
            base.OnDestroy();
        }
    }
}