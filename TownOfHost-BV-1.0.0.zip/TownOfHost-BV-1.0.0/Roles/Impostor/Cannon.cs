using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using AmongUs.GameOptions;
using BepInEx.Unity.IL2CPP.Utils;
using HarmonyLib;
using Hazel;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Vanilla;
using UnityEngine;

namespace TownOfHost.Roles.Impostor;

// ==========================================
// ① キャノンの役職本体クラス
// ==========================================
public class Cannon : RoleBase
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Cannon),
            player => new Cannon(player),
            CustomRoles.Cannon,
            () => RoleTypes.Shapeshifter,
            CustomRoleTypes.Impostor,
            514,
            null,
            "can",
            "#FF0000",
            false
        );

    public Cannon(PlayerControl player) : base(RoleInfo, player, null, null)
    {
        CannonManager.CannonPlayerId = player.PlayerId;
    }

    // イビルトラッカー風の矢印表示
    public override string GetSuffix(PlayerControl seer, PlayerControl seen = null, bool isForMeeting = false)
    {
        seen ??= seer;
        if (isForMeeting) return "";

        if (Player.PlayerId == seer.PlayerId && CannonManager.TargetPlayerId != 255)
        {
            return Utils.ColorString(Color.white, TargetArrow.GetArrows(Player, CannonManager.TargetPlayerId));
        }
        return "";
    }

    // 【変身ボタン押下時の処理】
    // 【変身ボタン押下時の処理】
    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        // 自身が死亡している、またはベント内なら不発
        if (Player.Data.IsDead || Player.inVent) return false;

        if (Player.GetCustomRole() != CustomRoles.Cannon)
        {
            CannonManager.ResetLockOn();
            return true;
        }

        // 💡 演出用のバニラ変身アニメーションは強制的にオフ
        animate = false;

        if (target != null)
        {
            // 💡 判定と処理の確定は、すべてホスト側のタイムラインに一元化する
            if (AmongUsClient.Instance.AmHost)
            {
                // ➔ 【再捕捉判定】すでに捕捉状態のプレイヤーをもう一度選んだとき（キル実行）
                if (CannonManager.TargetPlayerId == target.PlayerId)
                {
                    var state = PlayerState.GetByPlayerId(target.PlayerId);
                    if (state != null && !state.IsDead)
                    {
                        state.DeathReason = CustomDeathReason.Capture;
                        RoleTypes ghostRole = target.Data.Role.IsImpostor
                            ? RoleTypes.ImpostorGhost
                            : RoleTypes.CrewmateGhost;

                        target.RpcSetRole(ghostRole);
                        state.SetDead();
                    }

                    // ホスト側でロックオン解除
                    CannonManager.ResetLockOn();

                    // 💡 【重要】バニラの変身ボタンのクールダウンをあえてリセットせず、キル後は通常のクールダウンに入らせる
                }
                // ➔ 【新規捕捉判定】まだ捕捉していないプレイヤーを指定したとき（修正済）
                else
                {
                    if (CannonManager.TargetPlayerId != 255)
                    {
                        CannonManager.ResetLockOn();
                    }

                    // 🛠️ target.TargetId から target.PlayerId に修正！
                    CannonManager.StartLockOn(target.PlayerId);

                    // 捕捉成功時は次の発射（2回目）のために即座にボタンを復活させる
                    Player.RpcResetAbilityCooldown();
                }
            }

            // 💡 非ホスト（ローカル）側は、ホストの確定データをベースに描画（矢印など）を追従させるため
            // ここでの勝手な代入は行わず、バニラの変身処理だけをブロックする
        }

        // 🛑 本物のシェイプシフターに変身するのを完全に阻止する
        return false;
    }
    // ==========================================
    // ② キャノンの状態管理クラス（リセットパッチ内蔵）
    // ==========================================
    public static class CannonManager
    {
        public static byte CannonPlayerId = 255;
        public static byte TargetPlayerId = 255;
        public static Coroutine SyncTimerCoroutine = null;

        public static void StartLockOn(byte targetId)
        {
            CannonManager.TargetPlayerId = targetId;
            var player = Utils.GetPlayerById(CannonPlayerId);
            if (player != null)
            {
                TargetArrow.Add(CannonPlayerId, targetId);
            }

            if (CannonManager.SyncTimerCoroutine != null)
                HudManager.Instance.StopCoroutine(CannonManager.SyncTimerCoroutine);

            CannonManager.SyncTimerCoroutine = HudManager.Instance.StartCoroutine(SendNoiseToImpostorsLoop());
        }

        public static void ResetLockOn()
        {
            CannonManager.TargetPlayerId = 255;
            if (CannonManager.SyncTimerCoroutine != null)
            {
                HudManager.Instance.StopCoroutine(CannonManager.SyncTimerCoroutine);
                CannonManager.SyncTimerCoroutine = null;
            }
        }

        // メインスレッドを絶対にフリーズさせない安全コルーチン
        private static IEnumerator SendNoiseToImpostorsLoop()
        {
            while (true)
            {
                yield return new WaitForSeconds(1.0f);

                if (CannonManager.TargetPlayerId == 255)
                {
                    yield break;
                }

                PlayerControl target = null;
                foreach (var p in PlayerControl.AllPlayerControls)
                {
                    if (p.PlayerId == CannonManager.TargetPlayerId)
                    {
                        target = p;
                        break;
                    }
                }

                if (target == null || target.Data.IsDead)
                {
                    ResetLockOn();
                    yield break;
                }
            }
        }

        // ==========================================
        // ③ ゲーム開始・会議時のリセットパッチ
        // ==========================================
        [HarmonyPatch(typeof(IntroCutscene), nameof(IntroCutscene.BeginCrewmate))]
        public static class ResetPatchOnStart
        {
            public static void Postfix()
            {
                CannonManager.ResetLockOn();
            }
        }

        [HarmonyPatch(typeof(MeetingHud), nameof(MeetingHud.Start))]
        public static class ResetPatchOnMeetingStart
        {
            public static void Postfix()
            {
                CannonManager.ResetLockOn();
            }
        }

        [HarmonyPatch(typeof(ExileController), nameof(ExileController.WrapUp))]
        public static class ResetPatchOnMeetingEnd
        {
            public static void Postfix()
            {
                CannonManager.ResetLockOn();
            }
        }
    }
}