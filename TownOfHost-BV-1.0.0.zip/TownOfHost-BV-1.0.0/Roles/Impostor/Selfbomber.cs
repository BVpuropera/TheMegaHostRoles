using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Impostor;

public sealed class SelfBomber : RoleBase, IImpostor
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(SelfBomber),
            player => new SelfBomber(player),
            CustomRoles.SelfBomber,
            () => RoleTypes.Shapeshifter,
            CustomRoleTypes.Impostor,
            25464,
            SetUpOptionItem,
            "SelfBomber",
            introSound: () => GetIntroSound(RoleTypes.Engineer)
        );

    public SelfBomber(PlayerControl player)
        : base(RoleInfo, player)
    {
        _ = new LateTask(() =>
        {
            if (Player == null || !Player.IsAlive()) return;

            if (AmongUsClient.Instance.AmHost)
            {
                Player.SyncSettings();
            }
        }, 8f, "SelfBomberStartInit");
    }

    static OptionItem OptionKillCooldown;
    static OptionItem OptionExplosionRadius;

    enum OptionName
    {
        SelfBomberKillCooldown,
        SelfBomberExplosionRadius,
    }

    static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.SelfBomberKillCooldown, new(10f, 60f, 2.5f), 35f, false)
            .SetValueFormat(OptionFormat.Seconds);

        OptionExplosionRadius = FloatOptionItem.Create(RoleInfo, 11, OptionName.SelfBomberExplosionRadius, new(1.5f, 5.0f, 0.5f), 4.0f, false)
            .SetValueFormat(OptionFormat.None);
    }

    public bool CanUseKillButton() => Player.IsAlive();
    public bool CanUseSabotageButton() => true;
    public bool CanUseImpostorVentButton() => true;

    public float CalculateKillCooldown()
    {
        return OptionKillCooldown.GetFloat();
    }

    // ★ 運命の分岐点：変身ボタンが押された瞬間の判定（キャノンの仕組みを採用）
    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        // 死亡している、またはベント内なら不発
        if (Player.Data.IsDead || Player.inVent) return false;

        // 変身ボタンが押されたので自爆処理を実行！
        ExecuteSelfDestruct();

        // 💡 自身を本物のシェイプシフターに変身させないため、常に false を返す！
        // これにより変身演出も入らず、元の姿のまま即座に爆破・成仏します。
        return false;
    }

    // 自爆処理本体
    private void ExecuteSelfDestruct()
    {
        if (Player == null || !Player.IsAlive()) return;

        Logger.Info("寄れば咲かせ、大輪の花！自爆します！", "SelfBomber");

        if (AmongUsClient.Instance.AmHost)
        {
            Vector2 myPos = Player.transform.position;
            float radius = OptionExplosionRadius.GetFloat();

            // 1️⃣ 周囲のプレイヤーを巻き込みキル
            foreach (var killTarget in PlayerControl.AllPlayerControls)
            {
                if (killTarget == null || killTarget.Data == null || !killTarget.IsAlive() || killTarget.PlayerId == Player.PlayerId) continue;

                float distance = Vector2.Distance(killTarget.transform.position, myPos);

                // 範囲内にいて、かつインポスター陣営ではない場合
                if (distance <= radius && !killTarget.GetCustomRole().IsImpostor())
                {
                    // 巻き添え用のDeathReasonを設定
                    PlayerState.GetByPlayerId(killTarget.PlayerId).DeathReason = CustomDeathReason.Selfbomb;
                    killTarget.RpcMurderPlayer(killTarget);
                    Logger.Info($"[SelfBomber] {killTarget.GetNameWithRole()} を巻き込み爆破しました。(距離: {distance}m)", "SelfBomber");
                }
            }

            // 2️⃣ 自分自身の自殺処理
            // 本人の自爆用のDeathReasonを設定
            PlayerState.GetByPlayerId(Player.PlayerId).DeathReason = CustomDeathReason.Self;
            Player.RpcMurderPlayer(Player);
            Logger.Info("[SelfBomber] 自爆魔自身が死亡しました。", "SelfBomber");
        }
    }
}