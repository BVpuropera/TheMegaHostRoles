using System;
using AmongUs.GameOptions;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces; // 💡 追加
using UnityEngine;

namespace TownOfHost.Roles.Impostor;

// 💡 IImpostor インターフェースをしっかり継承させます
public sealed class Surpriser : RoleBase, IImpostor
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Surpriser),
            player => new Surpriser(player),
            CustomRoles.Surpriser, // ※Enumへの追加が必要です
            () => RoleTypes.Shapeshifter,
            CustomRoleTypes.Impostor,
            019927, // 固有ID
            null,   // 一旦オプション初期化はnull（Samurai方式）
            "Surpriser",
            "#FF69B4", // サプライズ感のあるピンク
            false,     // 💡 Samuraiに合わせてここをfalseにします（初手クルー化を防ぐため）
            introSound: () => GetIntroSound(RoleTypes.Impostor) // 💡 イントロをインポスターに固定
        );

    // すでに能力を使ったかどうかのフラグ
    public bool HasUsedSurprise { get; private set; } = false;

    public Surpriser(PlayerControl player) : base(RoleInfo, player) { }

    // サプライザー専用のターゲット管理用変数
    public byte TargetPlayerId { get; private set; } = 255; // 255は未ロックオン状態

    public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
    {
        // 自身が死亡している、またはベント内なら不発
        if (Player.Data.IsDead || Player.inVent) return false;

        // 自分自身の役職チェック
        if (Player.GetCustomRole() != CustomRoles.Surpriser)
        {
            TargetPlayerId = 255;
            return true;
        }

        animate = false; // サプライザーは姿を変えない

        if (target != null && target != Player)
        {
            // ➔ 【確定判定】すでにロックオンしているプレイヤーをもう一度選んだとき
            if (TargetPlayerId == target.PlayerId)
            {
                Logger.Info($"[Surpriser] {target.Data.PlayerName} をマッドサプライザーに変更します。", "Surpriser");

                if (AmongUsClient.Instance.AmHost)
                {
                    CustomRoleManager.CreateInstance(CustomRoles.MadSurpriser, target);
                }

                // 使用後はロックオンをリセット
                TargetPlayerId = 255;
                HasUsedSurprise = true;
            }
            // ➔ 【新規ロックオン判定】まだロックオンしていないプレイヤーを指定したとき
            else
            {
                TargetPlayerId = target.PlayerId;
                Logger.Info($"[Surpriser] {target.Data.PlayerName} をロックオンしました。", "Surpriser");

                // 即座に変身ゲージを回復させて2回目の確定選択に備える
                Player.RpcResetAbilityCooldown();
            }
        }

        // 本物のシェイプシフターに変身させないため常に false
        return false;
    }
}