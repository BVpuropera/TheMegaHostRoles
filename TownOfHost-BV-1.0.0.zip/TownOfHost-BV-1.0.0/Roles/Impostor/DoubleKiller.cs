/*
using AmongUs.GameOptions;
using Hazel;
using TownOfHost.Modules;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Impostor;

public sealed class DoubleKiller : RoleBase, IImpostor
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(DoubleKiller),
            player => new DoubleKiller(player),
            CustomRoles.DoubleKiller,
            () => RoleTypes.Phantom,
            CustomRoleTypes.Impostor,
            0928,
            SetUpOptionItem,
            "dk"
        );

    public DoubleKiller(PlayerControl player)
        : base(RoleInfo, player)
    {
        PhantomCooldown = OptionPhantomCooldown.GetFloat();
        KillCooldown = OptionKillCooldown.GetFloat();
        CanVent = !OptionCanVent.GetBool();
        CanSabotage = !OptionCanSabotage.GetBool();
        hasUsedPhantom = false;
    }

    static OptionItem OptionPhantomCooldown;
    static float PhantomCooldown;
    static OptionItem OptionKillCooldown;
    static float KillCooldown;
    static OptionItem OptionCanVent;
    static bool CanVent;
    static OptionItem OptionCanSabotage;
    static bool CanSabotage;
    bool hasUsedPhantom;

    enum OptionName
    {
        DoubleKillerPhantomCooldown,
        DoubleKillerKillCooldown,
        DoubleKillerCanVent,
        DoubleKillerCanSabotage,
    }

    static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.DoubleKillerKillCooldown, new(0.5f, 60f, 0.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);
        OptionPhantomCooldown = FloatOptionItem.Create(RoleInfo, 11, OptionName.DoubleKillerPhantomCooldown, new(0.5f, 60f, 0.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);
        OptionCanVent = BooleanOptionItem.Create(RoleInfo, 12, OptionName.DoubleKillerCanVent, true, false);
        OptionCanSabotage = BooleanOptionItem.Create(RoleInfo, 13, OptionName.DoubleKillerCanSabotage, true, false);
    }

    public float CalculateKillCooldown() => KillCooldown;
    public bool CanUseSabotageButton() => CanSabotage;
    public bool CanUseImpostorVentButton() => CanVent;

    public override void ApplyGameOptions(IGameOptions opt)
    {
        // ★ エラーの出ていた AURoleOptions を一旦コメントアウト
        // if (!hasUsedPhantom)
        //     AURoleOptions.PhantomCooldown = PhantomCooldown;
    }

    public void OnPhantomButtonClick()
    {
        if (hasUsedPhantom || !Player.IsAlive()) return;

        PlayerControl nearest = null;
        float minDist = Main.NormalOptions.KillDistance switch
        {
            0 => 1f,
            1 => 1.8f,
            _ => 2.5f
        };

        // ★ PlayerCatch を PlayerControl.AllPlayerControls に変更
        foreach (var target in PlayerControl.AllPlayerControls)
        {
            if (target == null || target.Data == null || target.Data.IsDead) continue;
            if (target.PlayerId == Player.PlayerId) continue;

            // ★ SuddenDeathMode の判定を除外して標準的な役職チェックのみに
            if (target.GetCustomRole().IsImpostor()) continue;

            float dist = Vector2.Distance(Player.GetTruePosition(), target.GetTruePosition());
            if (dist < minDist)
            {
                minDist = dist;
                nearest = target;
            }
        }

        if (nearest == null) return;

        hasUsedPhantom = true;
        float savedKillTimer = Player.killTimer;
        Vector2 targetPos = nearest.transform.position;

        // ★ 引数を標準の形式（キルする人、キルされる人）に変更
        // もしあなたの環境で動いていたキル関数があれば、それに差し替えてください
        CustomRoleManager.OnCheckMurder(Player, nearest);

        SnapToPosition(targetPos);

        // ★ LateTask の引数を3つに変更
        _ = new LateTask(() =>
        {
            if (!Player.IsAlive()) return;
            RestoreKillCooldown(savedKillTimer);
        }, 0.2f, "DoubleKillerRestoreCD");
    }

    private void RestoreKillCooldown(float cooldown)
    {
        cooldown = Mathf.Max(cooldown, 0f);

        Main.AllPlayerKillCooldown[Player.PlayerId] = cooldown * 2f;
        Player.SyncSettings();
        Player.RpcProtectedMurderPlayer();

        Player.killTimer = cooldown;
        Player.ResetKillCooldown();
        Player.SyncSettings();
    }

    private void SnapToPosition(Vector2 position)
    {
        Player.NetTransform.SnapTo(position);

        ushort sid = (ushort)(Player.NetTransform.lastSequenceId + 2U);
        var writer = AmongUsClient.Instance.StartRpcImmediately(
            Player.NetTransform.NetId, (byte)RpcCalls.SnapTo, Hazel.SendOption.Reliable);
        NetHelpers.WriteVector2(position, writer);
        writer.Write(sid);
        AmongUsClient.Instance.FinishRpcImmediately(writer);
    }
}
*/