using System.Collections.Generic;
using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;

namespace TownOfHost.Roles.Impostor;

public sealed class Bazooka : RoleBase, IImpostor
{
    public static readonly SimpleRoleInfo RoleInfo =
        SimpleRoleInfo.Create(
            typeof(Bazooka),
            player => new Bazooka(player),
            CustomRoles.Bazuka,
            () => RoleTypes.Shapeshifter,
            CustomRoleTypes.Impostor,
            9213,
            SetUpOptionItem,
            "Bazuka",
            introSound: () => GetIntroSound(RoleTypes.Noisemaker)
        );

    public Bazooka(PlayerControl player)
        : base(RoleInfo, player)
    {
        _ = new LateTask(() =>
        {
            if (Player == null || !Player.IsAlive()) return;

            if (AmongUsClient.Instance.AmHost)
            {
                Player.SyncSettings();
            }
        }, 8f, "BazookaStartInit");
    }

    private Vector2? bazookaTargetPosition = null;
    private bool isShifted = false;

    static OptionItem OptionKillCooldown;
    static OptionItem OptionExplosionRadius;

    enum OptionName
    {
        BazookaKillCooldown,
        BazookaExplosionRadius,
    }

    static void SetUpOptionItem()
    {
        OptionKillCooldown = FloatOptionItem.Create(RoleInfo, 10, OptionName.BazookaKillCooldown, new(10f, 60f, 2.5f), 30f, false)
            .SetValueFormat(OptionFormat.Seconds);

        OptionExplosionRadius = FloatOptionItem.Create(RoleInfo, 11, OptionName.BazookaExplosionRadius, new(1.5f, 5.0f, 0.5f), 3.0f, false)
            .SetValueFormat(OptionFormat.None);
    }

    public bool CanUseKillButton() => Player.IsAlive();
    public bool CanUseSabotageButton() => true;
    public bool CanUseImpostorVentButton() => true;

    public float CalculateKillCooldown()
    {
        return OptionKillCooldown.GetFloat();
    }

    // 侍の仕組みを取り入れたシェイプシフトイベントフック
    public override void OnShapeshift(PlayerControl target)
    {
        bool shapeshifting = !Is(target);

        if (shapeshifting)
        {
            // 1️⃣ 変身した瞬間（バズーカ砲着地地点をロックオン）
            if (!isShifted)
            {
                isShifted = true;
                bazookaTargetPosition = Player.transform.position;
                Logger.Info($"[Bazooka] バズーカ砲着地地点を登録: {bazookaTargetPosition}", "Bazooka");
            }
        }
        else
        {
            // 2️⃣ 変身解除した瞬間（どっかーん！）
            if (isShifted)
            {
                isShifted = false;
                ExecuteBazookaExplosion();
            }
        }
    }

    // 爆破処理本体
    private void ExecuteBazookaExplosion()
    {
        if (bazookaTargetPosition == null) return;

        Logger.Info($"[Bazooka] バズーカ発射！着地地点の周りを爆破します。", "Bazooka");

        if (AmongUsClient.Instance.AmHost)
        {
            Vector2 targetPos = bazookaTargetPosition.Value;
            float radius = OptionExplosionRadius.GetFloat();

            foreach (var killTarget in PlayerControl.AllPlayerControls)
            {
                if (killTarget == null || killTarget.Data == null || !killTarget.IsAlive() || killTarget.PlayerId == Player.PlayerId) continue;

                float distance = Vector2.Distance(killTarget.transform.position, targetPos);

                // 範囲内にいて、かつインポスター陣営ではない場合
                if (distance <= radius && !killTarget.GetCustomRole().IsImpostor())
                {
                    PlayerState.GetByPlayerId(killTarget.PlayerId).DeathReason = CustomDeathReason.TNT;
                    killTarget.RpcMurderPlayer(killTarget);
                    Logger.Info($"[Bazooka] {killTarget.GetNameWithRole()} を爆破キルしました！(距離: {distance}m)", "Bazooka");
                }
            }
        }

        bazookaTargetPosition = null;
    }
}