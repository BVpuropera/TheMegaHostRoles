using System;
using System.Collections;
using System.Collections.Generic;
using AmongUs.GameOptions;
using BepInEx.Unity.IL2CPP.Utils;
using HarmonyLib;
using TownOfHost;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;
using static TownOfHost.Options;

namespace TownOfHost.Roles.Impostor;

public sealed class EvilScientist : RoleBase, IImpostor, IStealthTimeLimit
{
    public static readonly SimpleRoleInfo RoleInfo = SimpleRoleInfo.Create(
        typeof(EvilScientist),
        player => new EvilScientist(player),
        CustomRoles.EvilScientist,
        () => RoleTypes.Shapeshifter,
        CustomRoleTypes.Impostor,
        81001,
        null,
        "fan",
        "#FF4500",
        true,
        introSound: () => GetIntroSound(RoleTypes.Scientist)
    );

    // 💡 インターフェース用の設定値保持
    private static float stealthDurationSetting;
    public float GetStealthDuration() => stealthDurationSetting;

    public bool IsStealth = false;

    public EvilScientist(PlayerControl player) : base(RoleInfo, player, null, null)
    {
        // 💡 コンストラクタでバニラ設定から秒数を読み込む
        if (GameOptionsManager.Instance?.CurrentGameOptions != null)
        {
            stealthDurationSetting = GameOptionsManager.Instance.CurrentGameOptions.GetFloat(FloatOptionNames.ShapeshifterDuration);
        }
        else
        {
            stealthDurationSetting = 10.0f;
        }
    }

    public override void ApplyGameOptions(IGameOptions opt)
    {
        // 💡 サムライと同じ！変身持続時間を「設定されたステルス時間」に同期する
        // これにより、クライアント側も自動的にこの秒数で変身解除タイマーが動きます
        AURoleOptions.ShapeshifterDuration = GetStealthDuration();
    }

    // 💡 OnCheckShapeshift は使わず、標準の変身フロー（OnShapeshift）に乗せる！
    // これによりINVALIDバグ（同期拒否）を完全に回避します
    public override void OnShapeshift(PlayerControl target)
    {
        // 自分自身に変身した瞬間（＝ボタンを押した時）は true
        // 時間経過で自動解除、または手動で解除した瞬間は false
        var shapeshifting = !Is(target);

        if (shapeshifting)
        {
            // ➔ ステルス開始（変身した瞬間）
            IsStealth = true;
        }
        else
        {
            // ➔ ステルス終了（変身解除した瞬間）
            IsStealth = false;

            if (AmongUsClient.Instance.AmHost)
            {
                // ホスト側でクールダウンをリセットする
                Player.RpcResetAbilityCooldown();
            }
        }
    }
}