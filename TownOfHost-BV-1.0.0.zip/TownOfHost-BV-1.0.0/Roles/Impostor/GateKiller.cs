using AmongUs.GameOptions;
using TownOfHost.Roles.Core;
using TownOfHost.Roles.Core.Interfaces;
using UnityEngine;
using UnityEngine.Networking;
using System.IO;
using System.Reflection;
using System;
using System.Collections.Generic; // ← これを追加！

namespace TownOfHost.Roles.Impostor
{
    public class GateKiller : RoleBase, IImpostor
    {
        public static readonly SimpleRoleInfo RoleInfo =
            SimpleRoleInfo.Create(
                typeof(GateKiller),
                player => new GateKiller(player),
                CustomRoles.GateKiller,
                () => RoleTypes.Shapeshifter,
                CustomRoleTypes.Impostor,
                98104,
                null,
                "gatekiller",
                "#FF0000",
                false,
                introSound: () => GetIntroSound(RoleTypes.Impostor)
            );

        // プレイヤーごとのゲート座標を保持する辞書
        public static Dictionary<byte, Vector2> GatePositions = new();

        public GateKiller(PlayerControl player) : base(RoleInfo, player)
        {
        }

        public override void Add()
        {
            GatePositions[Player.PlayerId] = Vector2.zero;
        }

        public override void ApplyGameOptions(IGameOptions opt)
        {
            AURoleOptions.ShapeshifterDuration = 1f;
        }

        // 【ここがポイント！】変身ボタンが押された瞬間の判定
        // 【変身ボタンが押された瞬間の判定】
        // 【変身ボタンが押された瞬間の判定】
        public override bool OnCheckShapeshift(PlayerControl target, ref bool animate)
        {
            // 死亡している、またはベント内なら不発
            if (Player.Data.IsDead || Player.inVent) return false;

            // 変身演出（アニメーション）を完全にオフにする
            animate = false;

            byte playerId = Player.PlayerId;
            Vector2 currentPos = Player.transform.position;

            if (!GatePositions.ContainsKey(playerId) || GatePositions[playerId] == Vector2.zero)
            {
                // 【1回目】まだゲートがない場合：その場に設置
                GatePositions[playerId] = currentPos;
                Logger.Info($"[GateKiller] ゲートを設置しました: {currentPos}", "GateKiller");

                return false;
            }
            else
            {
                // 【2回目以降】設置済みならその場所へテレポート！
                Vector2 targetPos = GatePositions[playerId];

                // ➔ Jumperのソースから判明した、全クライアント強制同期用RPCを呼び出す！
                Player.RpcSnapToForced(targetPos);

                Logger.Info($"[GateKiller] ゲートへ強制ワープしました: {targetPos}", "GateKiller");
                GatePositions[playerId] = Vector2.zero;

                return false;
            }
        }
    }
}